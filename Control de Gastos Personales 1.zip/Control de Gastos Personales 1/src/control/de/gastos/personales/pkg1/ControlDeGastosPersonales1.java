package control.de.gastos.personales.pkg1;

public class ControlDeGastosPersonales1 {

    public static void main(String[] args) {
        
    }
    
}
