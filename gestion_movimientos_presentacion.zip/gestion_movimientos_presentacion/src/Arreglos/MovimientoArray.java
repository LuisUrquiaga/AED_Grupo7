/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import Clases.Movimiento;
import java.util.Arrays;


public class MovimientoArray {
    int indice;
    int tamaño;
    public static Movimiento[] Lista = new Movimiento[20]; 
    
    public MovimientoArray(){
        //this.tamaño = 20;
        //indice = 0;
        //Lista = new Movimiento[this.tamaño];
    }
    
    
    public int obtenerIndice(){
        return this.indice;
    }
    
    public void establecerIndice(int indice){
        this.indice = indice;
    }    
    
    public Movimiento[] obtenerLista(){
        return Lista;
    }
    
    public Movimiento obtenerMovimiento(int id){
        for (int i=0; i<Lista.length; i++){
            if (Lista[i] != null && Lista[i].getId() == id){
                return Lista[i];
            }
        }
        return null;
    }
    
    public int obtenerIndicePorID(int id){
        int indice = -1;
        for (int i=0; i<Lista.length; i++){
            if (Lista[i] != null && Lista[i].getId() == id){
                indice = i;
            }
        }
        return indice;
    }
    
    public void llenarLista(Movimiento[] Lista){
        this.Lista = Lista;
    }
    
    public void agregar(Movimiento movimiento, int indiceDisp){
        Lista[indiceDisp] = movimiento;
        indice++;
    }
    
    public boolean editar(Movimiento movimiento){
        int indice = this.obtenerIndicePorID(movimiento.getId());
        if (indice == -1) {return false;}
        
        String nuevo_concepto = movimiento.getConcepto();
        String nuevo_tipo = movimiento.getTipo();
        Double nuevo_monto = movimiento.getMonto();
        Lista[indice].setConcepto(nuevo_concepto);
        Lista[indice].setTipo(nuevo_tipo);
        Lista[indice].setMonto(nuevo_monto);
        return true;
    }
    
    public void eliminar(int indice){
        Movimiento[] new_array = new Movimiento[20];
        int new_index = 0;
        for(int i=0, j=0; i<Lista.length; i++){
            if (Lista[i] != null && i != indice){
                //Lista[i].setCodigo(new_index + 1);
                new_array[new_index] = Lista[i];
                new_index++;
            }
        }
        
        Lista = new_array;
        //establecerIndice(new_index);
        
    }
    
    public void limpiarLista(){
        Arrays.fill(Lista, null);
    }
    
    // obtener elementos de tipo 'Libro' que no sean vacios o nulos
    public int obtenerElementosValidos(){
        int validos = 0;
        for (Movimiento movimiento: Lista){
            if (movimiento != null){
                validos++;
            }
        }
        return validos;
    }
    
    public void crearMovimiento(int index, Movimiento movimiento){
        System.out.println("IN: "+index);
        Lista[index] = movimiento;
    }
    
    public int obtenerIndiceVacio_v1(){
        int ind = this.obtenerElementosValidos() + 1;
        return ind;
    }
    
    public int obtenerIndiceVacio() {        
        for (int i = 0; i < Lista.length; i++) {
            if (Lista[i] == null) {
                return i; // Retorna el índice vacío
            }
        }
        return -1; // Retorna -1 si no hay índices vacíos
    }

    
    
}
