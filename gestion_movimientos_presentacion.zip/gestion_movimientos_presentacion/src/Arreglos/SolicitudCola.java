/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import Clases.Solicitud;
import java.util.ArrayList;
import java.util.List;

public class SolicitudCola {
    private SolicitudNodo inicio;
    private SolicitudNodo fin;

    public SolicitudCola() {
        this.inicio = null;
        this.fin = null;
    }

    public boolean estaVacia() {
        return inicio == null;
    }

    public void encolar(Solicitud solicitud) {
        SolicitudNodo nuevoNodo = new SolicitudNodo(solicitud);
        if (estaVacia()) {
            inicio = fin = nuevoNodo;
        } else {
            fin.siguiente = nuevoNodo;
            fin = nuevoNodo;
        }
    }

    public Solicitud desencolar() {
        if (estaVacia()) {
            System.out.println("La cola esta vacia.");
            return null;            
        }
        Solicitud solicitud = inicio.solicitud;
        inicio = inicio.siguiente;
        if (inicio == null) { 
            fin = null;
        }
        return solicitud;
    }

    public Solicitud inicio() {
        if (estaVacia()) {
            System.out.println("La cola esta vacia.");
            return null; 
        }
        return inicio.solicitud;
    }

    public List<Solicitud> obtenerLista() {
        List<Solicitud> lista = new ArrayList<>();
        SolicitudNodo actual = inicio;
        while (actual != null) {
            lista.add(actual.solicitud);
            actual = actual.siguiente;
        }
        return lista;
    }
}
