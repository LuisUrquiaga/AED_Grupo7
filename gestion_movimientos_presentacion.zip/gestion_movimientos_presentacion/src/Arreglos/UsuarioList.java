/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import Clases.Usuario;
import Clases.UsuarioNodo;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Node;


public class UsuarioList {
    private static UsuarioNodo head;

    public void agregar_v1(String nombre, int numero){
        Usuario nuevo_usuario = new Usuario(nombre, numero);
        UsuarioNodo nuevo_nodo = new UsuarioNodo(nuevo_usuario);
        
        if (head == null){
            head = nuevo_nodo;
        }{
            UsuarioNodo temporal = head;
            while (temporal.next != null){
                temporal = temporal.next;
            }
            temporal.next = nuevo_nodo; 
        }
    }
    
    public void agregar(String nombre, int numeroSocio) {
        Usuario nuevoUsuario = new Usuario(nombre, numeroSocio);
        UsuarioNodo nuevoNodo = new UsuarioNodo(nuevoUsuario);
        
        if (head == null) {
            head = nuevoNodo;
        } else {
            UsuarioNodo temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = nuevoNodo;
        }
    }
    
    
    public List<Usuario> obtenerUsuarios2() {
        List<Usuario> listaUsuarios = new ArrayList<>();
        UsuarioNodo temporal = head;
        while (temporal != null) {
            listaUsuarios.add(temporal.usuario);
            temporal = temporal.next;
        }
        return listaUsuarios;
    } 
    
    public List<Usuario> obtenerUsuarios() {
        if (head == null) {
            return null;
        }
        
        List<Usuario> listaUsuarios = new ArrayList<>();
        for (UsuarioNodo temporal = head; temporal != null; temporal = temporal.next) {
            listaUsuarios.add(temporal.usuario);
        }

        return listaUsuarios;
    }

    
    
    public boolean eliminar(int numero_socio) {
        if (head == null) {
            return false;
        }

        if (head.usuario.getNumero_socio() == numero_socio) {
            head = head.next;
            return true;
        }

        UsuarioNodo actual = head;
        while (actual.next != null) {
            if (actual.next.usuario.getNumero_socio() == numero_socio) {
                actual.next = actual.next.next; 
                return true;
            }
            actual = actual.next;
        }

        return false; 
    }
     
    
    // Busqueda Secuencial
    public Usuario busquedaPorNombre(String nombre) {
        UsuarioNodo temp = head; 
        while (temp != null) {
            if (temp.usuario.getNombre().equals(nombre.toUpperCase())) { 
                return temp.usuario; 
            }
            temp = temp.next; 
        }
        return null; 
    }
    
    public Usuario busquedaPorNumero(int numeroSocio) {
        UsuarioNodo temp = head; 
        while (temp != null) {
            if (temp.usuario.getNumero_socio() == numeroSocio) { 
                return temp.usuario; 
            }
            temp = temp.next; 
        }
        return null; 
    }

    
     public boolean verificarNumeroRepetido(int numero) {
        UsuarioNodo temp = head;
        while (temp != null) {
            if (temp.usuario.getNumero_socio() == numero) {
                System.out.println(temp.usuario.getNumero_socio()+" -- "+numero);
                return true; 
            }
            temp = temp.next;
        }
        return false; 
    }
    
    public void ordenarBurbuja() {
        if (head == null || head.next == null) {
            return; 
        }

        boolean swapped;
        do {
            swapped = false;
            UsuarioNodo actual = head;
            UsuarioNodo previo = null;

            while (actual.next != null) {
                UsuarioNodo next = actual.next;
                if (actual.usuario.getNumero_socio()> next.usuario.getNumero_socio()) {

                    if (previo == null) {
                        head = next;
                    } else {
                        previo.next = next;
                    }

                    actual.next = next.next;
                    next.next = actual;

                    swapped = true;
                    previo = next; 
                } else {
                    previo = actual;
                    actual = actual.next;
                }
            }
        } while (swapped);
    }
       
     
}
