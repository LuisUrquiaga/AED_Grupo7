/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import Clases.Devolucion;

public class DevolucionNodo {
    private Devolucion devolucion;
    private DevolucionNodo siguiente;

    public DevolucionNodo(Devolucion devolucion) {
        this.devolucion = devolucion;
        this.siguiente = null;
    }

    public Devolucion getDevolucion() {
        return devolucion;
    }

    public DevolucionNodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(DevolucionNodo siguiente) {
        this.siguiente = siguiente;
    }
}
