/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import Clases.Solicitud;

public class SolicitudNodo {
    Solicitud solicitud;
    SolicitudNodo siguiente;

    public SolicitudNodo (Solicitud solicitud) {
        this.solicitud = solicitud;
        this.siguiente = null;
    }
}
