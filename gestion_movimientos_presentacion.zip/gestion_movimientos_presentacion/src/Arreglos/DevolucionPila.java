/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import Clases.Devolucion;
import java.util.ArrayList;
import java.util.List;

public class DevolucionPila {
    private DevolucionNodo top;

    public DevolucionPila() {
        this.top = null;
    }

    public boolean estaVacia() {
        return top == null;
    }

    public void apilar(Devolucion devolucion) {
        DevolucionNodo nuevoNodo = new DevolucionNodo(devolucion);
        nuevoNodo.setSiguiente(top);
        top = nuevoNodo;
    }

    public Devolucion desapilar() {
        if (estaVacia()) {
            System.out.println("La pila esta vacia");
            return null;
        }
        Devolucion devolucion = top.getDevolucion();
        top = top.getSiguiente();
        return devolucion;
    }

    public Devolucion verTop() {
        if (estaVacia()) {
            System.out.println("La pila esta vacia");
            return null;
        }
        return top.getDevolucion();
    }

    public void mostrarPila() {
        DevolucionNodo actual = top;
        while (actual != null) {
            System.out.println(actual.getDevolucion());
            actual = actual.getSiguiente();
        }
    }
    
    public List<Devolucion> obtenerLista() {
        List<Devolucion> lista = new ArrayList<>();
        DevolucionNodo actual = top;
        while (actual != null) {
            lista.add(actual.getDevolucion());
            actual = actual.getSiguiente();
        }
        return lista;
    }
}
