/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import org.w3c.dom.Node;

public class UsuarioNodo {
    public Usuario usuario;
    public UsuarioNodo next;
    
    public UsuarioNodo(Usuario usuario){
        this.usuario = usuario;
        this.next = null;
    }
        
     
    
    
}
