/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.Random;


public class Devolucion {
    private int id;
    private String usuario;
    private String concepto;
    private Double monto;

    public Devolucion(String usuario, String concepto, Double monto) {
        this.id = generarID();
        this.usuario = usuario;
        this.concepto = concepto;
        this.monto = monto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }
    
     public int generarID(){
        Random random = new Random();
        // genera un numero de 6 digitos
        int id = random.nextInt(1000000);
        return id;
    }
}
