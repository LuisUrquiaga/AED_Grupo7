/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import Arreglos.MovimientoArray;
import Arreglos.UsuarioList;
import Clases.Movimiento;
import Clases.Usuario;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;


public class GUI_movimientos extends javax.swing.JFrame {

    private DefaultTableModel modeloTabla = new DefaultTableModel();
    private int tamañoArray = 20;
    private MovimientoArray MovimientoArray = new MovimientoArray();
    private String FORM_ACCION = "REGISTRO";
    private Movimiento[] MovimientosData = MovimientoArray.obtenerLista();
    
    public GUI_movimientos() {
        initComponents();
        
        this.setLocationRelativeTo(null);
        txt_codigo.setVisible(false);   
        btn_exportar.setVisible(false);
        btn_importar.setVisible(false);
        mostrarTablaMovimientos();
    }

    
    // METODOS    
    public void cargarComboUsuarios(){
        UsuarioList ul = new UsuarioList();
        List<Usuario> usuarios = ul.obtenerUsuarios();
        
        cb_usuario.removeAllItems();
        if (usuarios == null){
            System.out.println("No hay datos de usuarios");
            return;
        }
        for (Usuario usuario: usuarios){
            String nombre = usuario.getNombre();
            String numero = String.valueOf(usuario.getNumero_socio());
            cb_usuario.addItem(nombre+ " - " +numero);
            //System.out.println(usuario.getNombre());
        }
    }
    
    public void mostrarTablaMovimientos(){
        try {
            String columnas[] = {"Codigo","Usuario","Concepto", "Tipo", "Monto"};
            modeloTabla.setColumnIdentifiers(columnas);
            modeloTabla.setRowCount(0);
            table_movimientos.setModel(modeloTabla);
            
            Movimiento[] data = MovimientoArray.obtenerLista();          
            for (int i=0; i<data.length; i++){
                if (data[i] == null){
                    continue;
                }
                int codigo = data[i].getId();
                String usuario = data[i].getUsuario();
                String concepto = data[i].getConcepto();
                String tipo = data[i].getTipo();
                Double monto = data[i].getMonto();
                modeloTabla.addRow(new Object[]{codigo, usuario, concepto, tipo, monto});
            }
        } catch (Exception e) {
            System.out.println("Error Listado: "+e.getMessage());
        }
    }
    
    private void buscarMovimiento(String valor, String tipo_busqueda){
        modeloTabla.setRowCount(0);
        table_movimientos.setModel(modeloTabla);
        
        for (Movimiento movimiento: MovimientoArray.obtenerLista()){
            if (movimiento == null){
                continue;
            }
            int codigo = movimiento.getId();
            String concepto = movimiento.getConcepto();
            String tipo = movimiento.getTipo();
            Double monto = movimiento.getMonto();
            valor = valor.toUpperCase();
            switch (tipo_busqueda) {
                case "CONCEPTO":
                    if (concepto.toUpperCase().startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,concepto,tipo,monto });
                    }
                    break;
                case "TIPO":
                    if (tipo.toUpperCase().startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,concepto,tipo,monto });
                    }
                    break;
                case "MONTO":
                    if (String.valueOf(monto).startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,concepto,tipo,monto });
                    }
                    break;
                default:
                    //throw new AssertionError();
            }
            
            
        }
    }
    
    
    
    public void ExportarMovimientos(){        
        Movimiento[] movimientos = MovimientoArray.obtenerLista();
        if (MovimientoArray.obtenerElementosValidos()== 0){
            JOptionPane.showMessageDialog(null,"No hay datos que exportar");
            return;
        }
        int cantidad = 0;
        String ruta = ElegirRuta("EXPORT");
        if (ruta == null){
            return;
        }
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for(Movimiento movimiento: movimientos){
                if (movimiento != null){
                    int codigo = movimiento.getId();
                    String concepto = movimiento.getConcepto();
                    String tipo = movimiento.getTipo();
                    Double monto = movimiento.getMonto();

                    String cadena_exportacion = 
                            codigo +" -> "+ 
                            concepto +" -> "+ 
                            tipo +" -> "+
                            monto;
                    escritor.write( cadena_exportacion +"\n");
                    cantidad++;
                }
            }             
            JOptionPane.showMessageDialog(null,"Proceso Completado. ("+ cantidad +") movimientos exportados.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error: "+e.getMessage());
        }
    }
    public void ImportarMovimientos(){
       String ruta = ElegirRuta("IMPORT");
        if (ruta == null){
            return;
        }
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            MovimientoArray.limpiarLista();
            int cantidad = 0;
            int index = 0;
            int indiceImportado = 0;
            while((linea = lector.readLine()) != null && cantidad < tamañoArray){
                String[] data = linea.split(" -> ");
                if (data.length != 4){
                    System.out.println(index+": fila no valida");
                    index++;
                    continue;
                }
                int codigo = Integer.parseInt(data[0].replace(" ",""));
                String concepto = String.valueOf(data[1]);
                String tipo = String.valueOf(data[2]);
                Double monto = Double.valueOf(data[3]);

                MovimientoArray.crearMovimiento(indiceImportado, new Movimiento(
                    "No Data", concepto,tipo,monto
                ));
                indiceImportado++;
                cantidad++;
                
                index++;
            }
            mostrarTablaMovimientos();
            JOptionPane.showMessageDialog(null, "Proceso Completado. ("+cantidad+") movimientos importados.");
        } catch (IOException e) {
            System.out.println("err");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e.getMessage());
        } 
    }
    public String ElegirRuta(String tipo){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setPreferredSize(new Dimension(600, 450));
        fileChooser.setDialogTitle("Seleccione directorio");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de texto (.txt)","txt");
        fileChooser.setFileFilter(filter);
        fileChooser.setSelectedFile(new File("movimientos.txt"));
        int userSeleccion = 0;
        switch(tipo){
            case "EXPORT":
                userSeleccion = fileChooser.showSaveDialog(null);
                break;
            case "IMPORT":
                userSeleccion = fileChooser.showOpenDialog(null);
                break;
        }
        
        if (userSeleccion != JFileChooser.APPROVE_OPTION){
            JOptionPane.showMessageDialog(null, "ruta no seleccionada");
            return null;
        }
        String ruta = fileChooser.getSelectedFile().getAbsolutePath();
        if (!ruta.endsWith(".txt")) ruta += ".txt";  
        return ruta;
    }
    public void PermitirAlfabetico(java.awt.event.KeyEvent evt, JTextField campo){
        int key = evt.getKeyChar();

        boolean mayusculas = key >= 65 && key <= 90;
        boolean minusculas = key >= 97 && key <= 122;
        boolean espacio = key == 32;

         if (!(minusculas || mayusculas || espacio))
        {
            evt.consume();
        }
    }
    public void PermitirNumeros(java.awt.event.KeyEvent evt, JTextField campo){
        int key = evt.getKeyChar();

        boolean numeros = key >= 48 && key <= 57;
        if (!numeros){
            evt.consume();
        }

        if (campo.getText().trim().length() == 10) {
            evt.consume();
        }
    }
    
    public boolean verificarDouble(String valor) {
        try {
            Double.parseDouble(valor); // Puedes usar Integer.parseInt(valor) si es entero
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MENU_TABS = new javax.swing.JTabbedPane();
        TAB_LISTA = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_movimientos = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txt_buscar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cmb_tipo_busqueda = new javax.swing.JComboBox<>();
        btn_eliminar = new javax.swing.JButton();
        btn_registrar = new javax.swing.JButton();
        btn_importar = new javax.swing.JButton();
        btn_editar = new javax.swing.JButton();
        btn_exportar = new javax.swing.JButton();
        TAB_FORM = new javax.swing.JPanel();
        label_titulo_formulario = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cb_tipo = new javax.swing.JComboBox<>();
        label_error_concepto = new javax.swing.JLabel();
        txt_concepto = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        label_error_usuario = new javax.swing.JLabel();
        label_error_monto = new javax.swing.JLabel();
        txt_monto = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_guardar = new javax.swing.JButton();
        txt_codigo = new javax.swing.JTextField();
        cb_usuario = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        label_error_tipo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        MENU_TABS.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                MENU_TABSStateChanged(evt);
            }
        });

        TAB_LISTA.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel1.setText("Lista de Movimientos");
        TAB_LISTA.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 239, -1));

        table_movimientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table_movimientos);

        TAB_LISTA.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 760, 300));

        jLabel2.setText("Tipo de Busqueda:");
        TAB_LISTA.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 130, -1));

        txt_buscar.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txt_buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_buscarKeyReleased(evt);
            }
        });
        TAB_LISTA.add(txt_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 180, 30));

        jLabel3.setText("Buscar:");
        TAB_LISTA.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 70, -1));

        cmb_tipo_busqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TIPO", "CONCEPTO", "MONTO" }));
        TAB_LISTA.add(cmb_tipo_busqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 140, 30));

        btn_eliminar.setText("Eliminar");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 100, 90, 30));

        btn_registrar.setText("Registrar");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 100, 90, 30));

        btn_importar.setText("Importar");
        btn_importar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_importarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_importar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 60, 90, 30));

        btn_editar.setText("Editar");
        btn_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 100, 90, 30));

        btn_exportar.setText("Exportar");
        btn_exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exportarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_exportar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 60, 90, 30));

        MENU_TABS.addTab("Lista", TAB_LISTA);

        TAB_FORM.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_titulo_formulario.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        label_titulo_formulario.setText("Registrar Movimiento");
        TAB_FORM.add(label_titulo_formulario, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 239, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Concepto:");
        TAB_FORM.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 120, -1));

        cb_tipo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cb_tipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---", "ENTRADA", "SALIDA" }));
        cb_tipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_tipoActionPerformed(evt);
            }
        });
        TAB_FORM.add(cb_tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 100, 220, 34));

        label_error_concepto.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        label_error_concepto.setForeground(new java.awt.Color(255, 0, 0));
        TAB_FORM.add(label_error_concepto, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 220, 14));
        TAB_FORM.add(txt_concepto, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 220, 38));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Tipo de Movimiento:");
        TAB_FORM.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 170, -1));

        label_error_usuario.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        label_error_usuario.setForeground(new java.awt.Color(255, 0, 0));
        TAB_FORM.add(label_error_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 220, 12));

        label_error_monto.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        label_error_monto.setForeground(new java.awt.Color(255, 0, 0));
        TAB_FORM.add(label_error_monto, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, 220, 12));

        txt_monto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_montoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_montoKeyTyped(evt);
            }
        });
        TAB_FORM.add(txt_monto, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 210, 220, 34));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Monto:");
        TAB_FORM.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 180, 120, -1));

        btn_guardar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });
        TAB_FORM.add(btn_guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 224, 41));
        TAB_FORM.add(txt_codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(728, 18, 99, -1));

        cb_usuario.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cb_usuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---" }));
        cb_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_usuarioActionPerformed(evt);
            }
        });
        TAB_FORM.add(cb_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 220, 34));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Usuario:");
        TAB_FORM.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        label_error_tipo.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        label_error_tipo.setForeground(new java.awt.Color(255, 0, 0));
        TAB_FORM.add(label_error_tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, 220, 12));

        MENU_TABS.addTab("Registro", TAB_FORM);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_buscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarKeyReleased
        // TODO add your handling code here:
        try {
            String valor = txt_buscar.getText();
            String tipo = String.valueOf(cmb_tipo_busqueda.getSelectedItem());
            buscarMovimiento(valor, tipo);
        } catch (Exception e) {
            System.out.println("Error Busqueda: "+e.getMessage());
        }
    }//GEN-LAST:event_txt_buscarKeyReleased

    private void btn_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarActionPerformed
        // TODO add your handling code here:
        int fila = table_movimientos.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(null, "Registro no seleccionado");
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        Movimiento MovimientoData = MovimientoArray.obtenerMovimiento(codigo);
        if (MovimientoData == null){
            JOptionPane.showMessageDialog(null, "Registro no encontrado.");
            return;
        }
        txt_codigo.setText(String.valueOf(MovimientoData.getId()));
        txt_concepto.setText(MovimientoData.getConcepto());
        cb_tipo.setSelectedItem(MovimientoData.getTipo());
        txt_monto.setText(String.valueOf(MovimientoData.getMonto()));
                
        FORM_ACCION = "EDICION";
        label_titulo_formulario.setText("Edicion de Movimiento");
        
        MENU_TABS.setSelectedComponent(TAB_FORM);
    }//GEN-LAST:event_btn_editarActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        // TODO add your handling code here:
        int fila = table_movimientos.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(null, "Registro no seleccionado.");
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Eliminar Registro?","Cuidado!",JOptionPane.YES_NO_OPTION);
        if (confirmacion == 0){
            int indiceFila = MovimientoArray.obtenerIndicePorID(codigo);
            System.out.println("indice: "+indiceFila);
            if (indiceFila < 0){
                JOptionPane.showMessageDialog(null, "Movimiento desconocido.");
                return;
            }
            MovimientoArray.eliminar(indiceFila);
            JOptionPane.showMessageDialog(null, "Registro eliminado.");
            mostrarTablaMovimientos();
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_exportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exportarActionPerformed
        // TODO add your handling code here:
        ExportarMovimientos();
    }//GEN-LAST:event_btn_exportarActionPerformed

    private void btn_importarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_importarActionPerformed
        // TODO add your handling code here:
        ImportarMovimientos();
    }//GEN-LAST:event_btn_importarActionPerformed

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        // TODO add your handling code here:
        MENU_TABS.setSelectedComponent(TAB_FORM);
        cargarComboUsuarios();
    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed
        // TODO add your handling code here:
        label_titulo_formulario.setText("");
        label_error_usuario.setText("");
        label_error_concepto.setText("");
        label_error_tipo.setText("");
        label_error_monto.setText("");
        if (MovimientoArray.obtenerElementosValidos() == tamañoArray){
            JOptionPane.showMessageDialog(null, "Se ha llegado al Limite maximo de registros.");
            return;
        }
        
        String usuario = String.valueOf(cb_usuario.getSelectedItem());
        String concepto = String.valueOf(txt_concepto.getText());
        String tipo = String.valueOf(cb_tipo.getSelectedItem());
        
        int errores = 0;
        if (usuario.trim().isEmpty() || usuario == "---"){
            label_error_usuario.setText("Usuario requerido!");
            errores++;
        }
        if (concepto.isEmpty()){
            label_error_concepto.setText("Concepto requerido!");
            errores++;
        }
        if (tipo.trim().isEmpty() || tipo == "---"){
            label_error_tipo.setText("Tipo requerido!");
            errores++;
        }
        if (txt_monto.getText().trim().isEmpty()){
            label_error_monto.setText("Monto requerido!");
            errores++;
        }else {
            if (verificarDouble(txt_monto.getText()) == false){
                label_error_monto.setText("Monto invalido!");
                errores++;
            }
        }
        
        if (errores > 0){ return; }
        
        Double monto = Double.parseDouble(txt_monto.getText());
        String mensaje = "***";
        Movimiento MovimientoGuardar = new Movimiento();
        
        
        if (FORM_ACCION.equals("REGISTRO")){
            int indiceDisponible = MovimientoArray.obtenerIndiceVacio();
            if (indiceDisponible < 0){
                JOptionPane.showMessageDialog(null,"Limite de registros alcanzado.");
                return;
            }
            MovimientoGuardar = new Movimiento(usuario,concepto, tipo, monto);
            MovimientoArray.agregar(MovimientoGuardar, indiceDisponible);
            mensaje = "Movimiento guardado con exito.";
        
        }else if (FORM_ACCION.equals("EDICION")) {
            MovimientoGuardar.setId(Integer.parseInt(txt_codigo.getText()));
            MovimientoGuardar.setUsuario(usuario);
            MovimientoGuardar.setConcepto(txt_concepto.getText());
            MovimientoGuardar.setTipo(String.valueOf(cb_tipo.getSelectedItem()));
            MovimientoGuardar.setMonto(Double.parseDouble(txt_monto.getText()));
            MovimientoArray.editar(MovimientoGuardar);
            mensaje = "Movimiento actualizado!";
        }
        
        txt_codigo.setText("");
        txt_concepto.setText("");
        cb_tipo.setSelectedIndex(0);
        txt_monto.setText("");
        label_titulo_formulario.setText("Registrar Movimiento");
        FORM_ACCION = "REGISTRO";
        
        cb_usuario.setSelectedIndex(0);
        JOptionPane.showMessageDialog(null, mensaje);
        mostrarTablaMovimientos();
        MENU_TABS.setSelectedComponent(TAB_LISTA);
    }//GEN-LAST:event_btn_guardarActionPerformed

    private void cb_tipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_tipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_tipoActionPerformed

    private void cb_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_usuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_usuarioActionPerformed

    private void txt_montoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_montoKeyReleased
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txt_montoKeyReleased

    private void txt_montoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_montoKeyTyped
        //PermitirNumeros(evt, txt_monto);
    }//GEN-LAST:event_txt_montoKeyTyped

    private void MENU_TABSStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_MENU_TABSStateChanged
        // TODO add your handling code here:
        if (MENU_TABS.getSelectedComponent() == TAB_FORM){
            cargarComboUsuarios();
        }
    }//GEN-LAST:event_MENU_TABSStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI_movimientos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane MENU_TABS;
    private javax.swing.JPanel TAB_FORM;
    private javax.swing.JPanel TAB_LISTA;
    private javax.swing.JButton btn_editar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_exportar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_importar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.JComboBox<String> cb_tipo;
    private javax.swing.JComboBox<String> cb_usuario;
    private javax.swing.JComboBox<String> cmb_tipo_busqueda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_error_concepto;
    private javax.swing.JLabel label_error_monto;
    private javax.swing.JLabel label_error_tipo;
    private javax.swing.JLabel label_error_usuario;
    private javax.swing.JLabel label_titulo_formulario;
    private javax.swing.JTable table_movimientos;
    private javax.swing.JTextField txt_buscar;
    private javax.swing.JTextField txt_codigo;
    private javax.swing.JTextField txt_concepto;
    private javax.swing.JTextField txt_monto;
    // End of variables declaration//GEN-END:variables
}
