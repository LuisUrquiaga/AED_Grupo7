/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

package GUI;

import Arreglos.DevolucionPila;
import Arreglos.UsuarioList;
import Clases.Devolucion;
import Clases.Usuario;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GUI_Devolucion extends javax.swing.JFrame {
    
    private DefaultTableModel modeloTabla = new DefaultTableModel();
    DevolucionPila dpila = new DevolucionPila();
    public GUI_Devolucion() {
        initComponents();
        //dpila.apilar(new Devolucion("Ana - 111", "Mora", 150.0));
        
        cargarComboUsuarios();
        mostrarTablaDevoluciones();
    }
    
    public void cargarComboUsuarios(){
        UsuarioList ul = new UsuarioList();
        List<Usuario> usuarios = ul.obtenerUsuarios();
        
        cb_usuario.removeAllItems();
        cb_usuario.addItem("---");
        if (usuarios == null){
            System.out.println("No hay datos de usuarios");
            return;
        }
        
        for (Usuario usuario: usuarios){
            String nombre = usuario.getNombre();
            String numero = String.valueOf(usuario.getNumero_socio());
            cb_usuario.addItem(nombre+ " - " +numero);
        }
    }
    
    public void mostrarTablaDevoluciones(){
        try {
            String columnas[] = {"#","Codigo","Usuario","Concepto", "Monto"};
            modeloTabla.setColumnIdentifiers(columnas);
            modeloTabla.setRowCount(0);
            table_devolucion.setModel(modeloTabla);
            
            
            List<Devolucion> data = dpila.obtenerLista();
            System.out.println(data);
            int ind = 1;
            for (Devolucion devolucion: data){
                if (devolucion == null){
                    System.out.println("Err");
                    continue;
                }
                int id = devolucion.getId();
                String usuario = devolucion.getUsuario();
                String concepto = devolucion.getConcepto();
                Double monto = devolucion.getMonto();
                modeloTabla.addRow(new Object[]{ind, id, usuario, concepto, monto});
                ind++;
            }
            
        } catch (Exception e) {
            System.out.println("Error - mostrar tabla: "+e.getMessage());
        }       
    }
    
    public boolean verificarDouble(String valor) {
        try {
            Double.parseDouble(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_monto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_concepto = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btn_registrar = new javax.swing.JButton();
        label_error_monto = new javax.swing.JLabel();
        cb_usuario = new javax.swing.JComboBox<>();
        label_error_usuario = new javax.swing.JLabel();
        label_error_concepto = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_devolucion = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btn_registrar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Haettenschweiler", 0, 30)); // NOI18N
        jLabel1.setText("DEVOLUCIONES - Pagos");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 239, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registrar", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 13))); // NOI18N
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Usuario:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 32, -1, -1));

        txt_monto.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPanel1.add(txt_monto, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 58, 206, 32));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Monto:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 32, -1, -1));

        txt_concepto.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jPanel1.add(txt_concepto, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 58, 200, 32));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Concepto:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 32, -1, -1));

        btn_registrar.setBackground(new java.awt.Color(20, 20, 20));
        btn_registrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_registrar.setForeground(new java.awt.Color(255, 255, 255));
        btn_registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/save.png"))); // NOI18N
        btn_registrar.setText("Guardar");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });
        jPanel1.add(btn_registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, 206, 43));

        label_error_monto.setForeground(new java.awt.Color(255, 0, 0));
        jPanel1.add(label_error_monto, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, 210, 10));

        cb_usuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---" }));
        jPanel1.add(cb_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 58, 206, 32));

        label_error_usuario.setForeground(new java.awt.Color(255, 0, 0));
        jPanel1.add(label_error_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 96, 206, 10));

        label_error_concepto.setForeground(new java.awt.Color(255, 0, 0));
        jPanel1.add(label_error_concepto, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 200, 10));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 70, 672, 175));

        table_devolucion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table_devolucion);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 309, 670, 250));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel5.setText("Solicitudes Actuales:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, -1, -1));

        btn_registrar1.setBackground(new java.awt.Color(20, 20, 20));
        btn_registrar1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_registrar1.setForeground(new java.awt.Color(255, 255, 255));
        btn_registrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/rotate-ccw.png"))); // NOI18N
        btn_registrar1.setText("Deshacer");
        btn_registrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrar1ActionPerformed(evt);
            }
        });
        getContentPane().add(btn_registrar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 206, 43));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        
        label_error_concepto.setText("");
        label_error_monto.setText("");
        label_error_usuario.setText("");
        
        int errores = 0;
        String usuario = String.valueOf(cb_usuario.getSelectedItem());
        System.out.println(""+usuario);
        if (usuario.trim().isEmpty() || usuario == "---"){
            System.out.println("Error usuario");
            label_error_monto.setText("Campo requerido, Registre usuarios");
            errores++;
        }
        
        if (String.valueOf(txt_concepto.getText()).trim().isEmpty()){
            label_error_usuario.setText("Campo requerido.");
            errores++;
        }
        
        if (txt_monto.getText().trim().isEmpty()){
            label_error_concepto.setText("Monto requerido!");
            errores++;
        }else {
            if (verificarDouble(txt_monto.getText()) == false){
                label_error_concepto.setText("Monto invalido!");
                errores++;
            }
        } 
        
        if (errores > 0){ return; }
        
        
        String concepto = String.valueOf(txt_concepto.getText());
        Double monto = Double.parseDouble(txt_monto.getText());
        
        dpila.apilar(new Devolucion(usuario, concepto, monto));
        
        cb_usuario.setSelectedIndex(0);
        txt_concepto.setText("");
        txt_monto.setText("");
        
        mostrarTablaDevoluciones();
        JOptionPane.showMessageDialog(null, "Devolucion Registrada");

    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_registrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrar1ActionPerformed
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Deshacer el ultimo registro?","Cuidado!",JOptionPane.YES_NO_OPTION);
        if (confirmacion == 0){
            if (dpila.desapilar() != null){
                JOptionPane.showMessageDialog(null, "Proceso completado.");
                mostrarTablaDevoluciones();
            }else {
                JOptionPane.showMessageDialog(null, "No se pudo procesar.");
            }
        }
    }//GEN-LAST:event_btn_registrar1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_Devolucion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_Devolucion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_Devolucion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_Devolucion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI_Devolucion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_registrar;
    private javax.swing.JButton btn_registrar1;
    private javax.swing.JComboBox<String> cb_usuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_error_concepto;
    private javax.swing.JLabel label_error_monto;
    private javax.swing.JLabel label_error_usuario;
    private javax.swing.JTable table_devolucion;
    private javax.swing.JTextField txt_concepto;
    private javax.swing.JTextField txt_monto;
    // End of variables declaration//GEN-END:variables

}
