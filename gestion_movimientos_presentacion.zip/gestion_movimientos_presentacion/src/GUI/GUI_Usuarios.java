/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import Arreglos.UsuarioList;
import Clases.Usuario;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;


public class GUI_Usuarios extends javax.swing.JFrame {

    private DefaultTableModel modeloTabla = new DefaultTableModel();
    private UsuarioList UsuarioList = new UsuarioList();
    private List<Usuario> UsuariosData = UsuarioList.obtenerUsuarios();
    private String FORM_ACCION = "REGISTRO";
    
    public GUI_Usuarios() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        UsuarioList.agregar("Joshua", 123);
        mostrarTablaUsuarios();
    }

    
    // METODOS
     public void mostrarTablaUsuarios(){
        try {
            String columnas[] = {"Nº","Nombre","Numero Socio"};
            modeloTabla.setColumnIdentifiers(columnas);
            modeloTabla.setRowCount(0);
            table_usuarios.setModel(modeloTabla);            
            
            List<Usuario> data = UsuarioList.obtenerUsuarios();
            
            if (data != null){
                int index = 0;
                for (Usuario usuario: data){ 
                    int indice = index+1;
                    String nombre = usuario.getNombre();
                    int numero = usuario.getNumero_socio();
                    modeloTabla.addRow(new Object[]{ indice, nombre, numero});
                    index++;
                }
            }else {
                modeloTabla.addRow(new Object[]{"","Sin Datos",""});
            }
                        
        } catch (Exception e) {
            System.out.println("Error Listado: "+e.getMessage());
        }
    }

    private static boolean esNumero(String cadena){
        try {
          Integer.parseInt(cadena);
          return true;
        } catch (NumberFormatException nfe){
          return false;
        }
    }
    
    private void buscarUsuario(String valor, String tipo_busqueda){
        modeloTabla.setRowCount(0);
        table_usuarios.setModel(modeloTabla);
        Usuario resultado = null;
        switch (tipo_busqueda) {
            case "NOMBRE":
                resultado = UsuarioList.busquedaPorNombre(valor);
                break;
            case "NUMERO SOCIO":
                resultado = UsuarioList.busquedaPorNumero(Integer.parseInt(valor));
                break;
            default:
                //throw new AssertionError();
        }
        if (resultado == null) {
            modeloTabla.addRow(new Object[]{ "","Sin datos","" });
            return;
        }
        modeloTabla.addRow(new Object[]{ 1,resultado.getNombre(),resultado.getNumero_socio() });
    }
    
    
    
    public void ExportarUsuarios(){        
        List<Usuario> data = UsuariosData;
        if (data == null || data.isEmpty()){
            JOptionPane.showMessageDialog(null,"No hay datos que exportar");
            return;
        }
        int cantidad = 0;
        String ruta = ElegirRuta("EXPORT");
        if (ruta == null){
            return;
        }
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for(Usuario usuario: data){
                if (usuario != null){
                    System.out.println(""+usuario.getNombre());
                    String nombre = usuario.getNombre();
                    int numero = usuario.getNumero_socio();

                    String cadena_exportacion = 
                            nombre +" -> "+ 
                            numero;
                    escritor.write( cadena_exportacion +"\n");
                    cantidad++;
                }
            }             
            JOptionPane.showMessageDialog(null,"Proceso Completado. ("+ cantidad +") usuarios exportados.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error: "+e.getMessage());
        }
    }
    public void ImportarUsuarios(){
       String ruta = ElegirRuta("IMPORT");
        if (ruta == null){
            return;
        }
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            int cantidad = 0;
            int index = 0;
            int indiceImportado = 0;
            while((linea = lector.readLine()) != null){
                String[] data = linea.split(" -> ");
                if (data.length != 3){
                    System.out.println(index+": fila no valida");
                    index++;
                    continue;
                }
                int codigo = Integer.parseInt(data[0].replace(" ",""));
                String nombre = String.valueOf(data[1]);
                String numero = String.valueOf(data[2]);

                
                indiceImportado++;
                cantidad++;
                
                index++;
            }
            mostrarTablaUsuarios();
            JOptionPane.showMessageDialog(null, "Proceso Completado. ("+cantidad+") usuarios importados.");
        } catch (IOException e) {
            System.out.println("err");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e.getMessage());
        } 
    }
    public String ElegirRuta(String tipo){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setPreferredSize(new Dimension(600, 450));
        fileChooser.setDialogTitle("Seleccione directorio");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de texto (.txt)","txt");
        fileChooser.setFileFilter(filter);
        fileChooser.setSelectedFile(new File("usuarios.txt"));
        int userSeleccion = 0;
        switch(tipo){
            case "EXPORT":
                userSeleccion = fileChooser.showSaveDialog(null);
                break;
            case "IMPORT":
                userSeleccion = fileChooser.showOpenDialog(null);
                break;
        }
        
        if (userSeleccion != JFileChooser.APPROVE_OPTION){
            JOptionPane.showMessageDialog(null, "ruta no seleccionada");
            return null;
        }
        String ruta = fileChooser.getSelectedFile().getAbsolutePath();
        if (!ruta.endsWith(".txt")) ruta += ".txt";  
        return ruta;
    }
    
    public void PermitirAlfabetico(java.awt.event.KeyEvent evt, JTextField campo){
        int key = evt.getKeyChar();

        boolean mayusculas = key >= 65 && key <= 90;
        boolean minusculas = key >= 97 && key <= 122;
        boolean espacio = key == 32;

         if (!(minusculas || mayusculas || espacio))
        {
            evt.consume();
        }
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MENU_TABS = new javax.swing.JTabbedPane();
        TAB_LISTA = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_usuarios = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txt_buscar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cmb_tipo_busqueda = new javax.swing.JComboBox<>();
        btn_eliminar = new javax.swing.JButton();
        btn_registrar = new javax.swing.JButton();
        btn_exportar = new javax.swing.JButton();
        btn_ordenar = new javax.swing.JButton();
        TAB_FORM = new javax.swing.JPanel();
        label_titulo_formulario = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        label_error_numero = new javax.swing.JLabel();
        txt_numero_socio = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        label_error_nombre = new javax.swing.JLabel();
        btn_guardar = new javax.swing.JButton();
        txt_nombre = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        MENU_TABS.setBackground(new java.awt.Color(255, 255, 255));

        TAB_LISTA.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Haettenschweiler", 0, 30)); // NOI18N
        jLabel1.setText("Lista de Usuarios");
        TAB_LISTA.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 239, -1));

        table_usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table_usuarios);

        TAB_LISTA.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 760, 300));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Tipo de Busqueda:");
        TAB_LISTA.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 130, -1));

        txt_buscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_buscarKeyReleased(evt);
            }
        });
        TAB_LISTA.add(txt_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 180, 40));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Buscar:");
        TAB_LISTA.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 70, -1));

        cmb_tipo_busqueda.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmb_tipo_busqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NOMBRE", "NUMERO SOCIO" }));
        cmb_tipo_busqueda.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmb_tipo_busquedaItemStateChanged(evt);
            }
        });
        TAB_LISTA.add(cmb_tipo_busqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 140, 40));

        btn_eliminar.setBackground(new java.awt.Color(20, 20, 20));
        btn_eliminar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btn_eliminar.setForeground(new java.awt.Color(255, 255, 255));
        btn_eliminar.setText("Eliminar");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 90, 180, 40));

        btn_registrar.setBackground(new java.awt.Color(20, 20, 20));
        btn_registrar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btn_registrar.setForeground(new java.awt.Color(255, 255, 255));
        btn_registrar.setText("Registrar");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 90, 40));

        btn_exportar.setBackground(new java.awt.Color(20, 20, 20));
        btn_exportar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btn_exportar.setForeground(new java.awt.Color(255, 255, 255));
        btn_exportar.setText("Exportar");
        btn_exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exportarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_exportar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 40, 90, 40));

        btn_ordenar.setBackground(new java.awt.Color(20, 20, 20));
        btn_ordenar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btn_ordenar.setForeground(new java.awt.Color(255, 255, 255));
        btn_ordenar.setText("Ordenar Numeros");
        btn_ordenar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ordenarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_ordenar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 40, 180, 40));

        MENU_TABS.addTab("Lista", TAB_LISTA);

        TAB_FORM.setBackground(new java.awt.Color(255, 255, 255));
        TAB_FORM.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_titulo_formulario.setFont(new java.awt.Font("Haettenschweiler", 0, 30)); // NOI18N
        label_titulo_formulario.setText("Registrar Usuario");
        TAB_FORM.add(label_titulo_formulario, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 239, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Numero de Socio:");
        TAB_FORM.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 120, -1));

        label_error_numero.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        label_error_numero.setForeground(new java.awt.Color(204, 0, 0));
        TAB_FORM.add(label_error_numero, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 240, 14));

        txt_numero_socio.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        TAB_FORM.add(txt_numero_socio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 240, 32));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Nombre:");
        TAB_FORM.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 120, -1));

        label_error_nombre.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        label_error_nombre.setForeground(new java.awt.Color(255, 0, 0));
        TAB_FORM.add(label_error_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 240, 12));

        btn_guardar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });
        TAB_FORM.add(btn_guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 241, 41));

        txt_nombre.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txt_nombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nombreKeyTyped(evt);
            }
        });
        TAB_FORM.add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 241, 35));

        MENU_TABS.addTab("Registro", TAB_FORM);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_buscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarKeyReleased
        // TODO add your handling code here:
        try {
            String valor = txt_buscar.getText();
            String tipo = String.valueOf(cmb_tipo_busqueda.getSelectedItem());
            if (valor.isEmpty()){
                mostrarTablaUsuarios();
                return;
            }
            buscarUsuario(valor, tipo);
        } catch (Exception e) {
            System.out.println("Error Busqueda: "+e.getMessage());
        }
    }//GEN-LAST:event_txt_buscarKeyReleased

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        // TODO add your handling code here:
        int fila = table_usuarios.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(null, "Usuario no seleccionado.");
            return;
        }
        String numero = String.valueOf(modeloTabla.getValueAt(fila, 2));
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Eliminar Usuario?","Cuidado!",JOptionPane.YES_NO_OPTION);
        if (!numero.trim().isEmpty() && numero != null && confirmacion == 0){
            System.out.println("codigo "+numero);
            UsuarioList.eliminar(Integer.parseInt(numero));
            JOptionPane.showMessageDialog(null, "Usuario eliminado.");
            mostrarTablaUsuarios();
        }else {
            JOptionPane.showMessageDialog(null, "Registro Invalido.");
            System.out.println("Registro Invalido.");
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_exportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exportarActionPerformed
        // TODO add your handling code here:
        ExportarUsuarios();
    }//GEN-LAST:event_btn_exportarActionPerformed

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        // TODO add your handling code here:
        MENU_TABS.setSelectedComponent(TAB_FORM);
    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed
        try {
            label_error_nombre.setText("");
            label_error_numero.setText("");

            
            int errores = 0;
            if (txt_nombre.getText().length() == 0){
                label_error_nombre.setText("Dato requerido!");
                errores++;
            }
            if (txt_numero_socio.getText().trim().isEmpty()){
                label_error_numero.setText("Dato requerido!");
                errores++;
            }else {
                if (!esNumero(txt_numero_socio.getText()) || Integer.parseInt(txt_numero_socio.getText()) <= 0){
                    label_error_numero.setText("Numero de Socio invalido!");
                    errores++;
                }else {
                    
                    Usuario verificarRepetido = UsuarioList.busquedaPorNumero(Integer.parseInt(txt_numero_socio.getText()));
                    if (verificarRepetido != null){
                        label_error_numero.setText("Numero de Socio ocupado!");
                        errores++;
                    }
                }
            }
            
            if (errores > 0){ return; }
            
            String nombre = String.valueOf(txt_nombre.getText());
            int numero = Integer.parseInt(txt_numero_socio.getText());

            if (UsuarioList.verificarNumeroRepetido(numero)){
                System.out.println("Usuario Repetido");
                label_error_numero.setText("El Numero de Socio ya esta en uso!");
                return;
            }

            UsuarioList.agregar(nombre, numero);
            JOptionPane.showMessageDialog(null, "Usuario Agregado!");

            txt_nombre.setText("");
            txt_numero_socio.setText("");
            label_error_nombre.setText("");
            label_error_numero.setText("");

            MENU_TABS.setSelectedComponent(TAB_LISTA);
            mostrarTablaUsuarios();
        } catch (Exception e) {
            System.out.println("Error Registro: "+e.getMessage());
        }
    }//GEN-LAST:event_btn_guardarActionPerformed

    private void cmb_tipo_busquedaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmb_tipo_busquedaItemStateChanged
        // TODO add your handling code here:
        try {
            String valor = txt_buscar.getText();
            String tipo = String.valueOf(cmb_tipo_busqueda.getSelectedItem());
            if (valor.isEmpty()){
                mostrarTablaUsuarios();
                return;
            }
            buscarUsuario(valor, tipo);
        } catch (Exception e) {
            System.out.println("Error Busqueda: "+e.getMessage());
        }
    }//GEN-LAST:event_cmb_tipo_busquedaItemStateChanged

    private void btn_ordenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ordenarActionPerformed
        // TODO add your handling code here:
        UsuarioList.ordenarBurbuja();
        mostrarTablaUsuarios();
    }//GEN-LAST:event_btn_ordenarActionPerformed

    private void txt_nombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nombreKeyTyped
        // TODO add your handling code here:
        PermitirAlfabetico(evt, txt_nombre);
    }//GEN-LAST:event_txt_nombreKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI_Usuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane MENU_TABS;
    private javax.swing.JPanel TAB_FORM;
    private javax.swing.JPanel TAB_LISTA;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_exportar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_ordenar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.JComboBox<String> cmb_tipo_busqueda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_error_nombre;
    private javax.swing.JLabel label_error_numero;
    private javax.swing.JLabel label_titulo_formulario;
    private javax.swing.JTable table_usuarios;
    private javax.swing.JTextField txt_buscar;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_numero_socio;
    // End of variables declaration//GEN-END:variables
}
