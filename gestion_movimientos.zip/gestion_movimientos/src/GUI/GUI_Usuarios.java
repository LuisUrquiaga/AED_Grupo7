/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import Arreglos.UsuarioLinked;
import Clases.Usuario;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;


public class GUI_Usuarios extends javax.swing.JFrame {

    private DefaultTableModel modeloTabla = new DefaultTableModel();
    private UsuarioLinked UsuarioLink = new UsuarioLinked();
    private String FORM_ACCION = "REGISTRO";
    
    public GUI_Usuarios() {
        initComponents();
        
        this.setLocationRelativeTo(null);
        UsuarioLink.agregar("JOSE","4353453-443");
        UsuarioLink.agregar("MARY","2223332-443");
        mostrarTablaUsuarios();
    }

    
    // METODOS
     public void mostrarTablaUsuarios(){
        try {
            String columnas[] = {"Codigo","Nombre","Numero Socio"};
            modeloTabla.setColumnIdentifiers(columnas);
            modeloTabla.setRowCount(0);
            table_usuarios.setModel(modeloTabla);
            
            
            List<Usuario> data = UsuarioLink.obtenerUsuarios();
            if (data != null){
                for (Usuario usuario: data){
                    int codigo = usuario.getCodigo();
                    String nombre = usuario.getNombre();
                    String numero = usuario.getNumero_socio();
                    modeloTabla.addRow(new Object[]{codigo, nombre, numero});
                }
                
            }else {
                modeloTabla.addRow(new Object[]{"","Sin Datos",""});
            }
            
        } catch (Exception e) {
            System.out.println("Error Listado: "+e.getMessage());
        }
    }

    
    
    private void buscarUsuario(String valor, String tipo_busqueda){
        modeloTabla.setRowCount(0);
        table_usuarios.setModel(modeloTabla);
        List<Usuario> data = UsuarioLink.obtenerUsuarios();
        if (data == null) {return;}
        for (Usuario usuario: data){
            if (usuario == null){
                continue;
            }
            int codigo = usuario.getCodigo();
            String nombre = usuario.getNombre();
            String numero = usuario.getNumero_socio();
            valor = valor.toUpperCase();
            switch (tipo_busqueda) {
                case "NOMBRE":
                    if (nombre.toUpperCase().startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,nombre,numero });
                    }
                    break;
                case "NUMERO SOCIO":
                    if (numero.toUpperCase().startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,nombre,numero });
                    }
                    break;
                default:
                    //throw new AssertionError();
            }       
        }
    }
    
    
    
    public void ExportarUsuarios(){        
        List<Usuario> data = UsuarioLink.obtenerUsuarios();
        if (data == null || data.isEmpty()){
            JOptionPane.showMessageDialog(null,"No hay datos que exportar");
            return;
        }
        int cantidad = 0;
        String ruta = ElegirRuta("EXPORT");
        if (ruta == null){
            return;
        }
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for(Usuario usuario: data){
                if (usuario != null){
                    System.out.println(""+usuario.getNombre());
                    int codigo = usuario.getCodigo();
                    String nombre = usuario.getNombre();
                    String numero = usuario.getNumero_socio();

                    String cadena_exportacion = 
                            codigo +" -> "+ 
                            nombre +" -> "+ 
                            numero;
                    escritor.write( cadena_exportacion +"\n");
                    cantidad++;
                }
            }             
            JOptionPane.showMessageDialog(null,"Proceso Completado. ("+ cantidad +") usuarios exportados.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error: "+e.getMessage());
        }
    }
    public void ImportarUsuarios(){
       String ruta = ElegirRuta("IMPORT");
        if (ruta == null){
            return;
        }
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            //UsuarioLink.limpiarLista();
            int cantidad = 0;
            int index = 0;
            int indiceImportado = 0;
            while((linea = lector.readLine()) != null){
                String[] data = linea.split(" -> ");
                if (data.length != 3){
                    System.out.println(index+": fila no valida");
                    index++;
                    continue;
                }
                int codigo = Integer.parseInt(data[0].replace(" ",""));
                String nombre = String.valueOf(data[1]);
                String numero = String.valueOf(data[2]);

                
                indiceImportado++;
                cantidad++;
                
                index++;
            }
            mostrarTablaUsuarios();
            JOptionPane.showMessageDialog(null, "Proceso Completado. ("+cantidad+") usuarios importados.");
        } catch (IOException e) {
            System.out.println("err");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e.getMessage());
        } 
    }
    public String ElegirRuta(String tipo){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setPreferredSize(new Dimension(600, 450));
        fileChooser.setDialogTitle("Seleccione directorio");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de texto (.txt)","txt");
        fileChooser.setFileFilter(filter);
        fileChooser.setSelectedFile(new File("usuarios.txt"));
        int userSeleccion = 0;
        switch(tipo){
            case "EXPORT":
                userSeleccion = fileChooser.showSaveDialog(null);
                break;
            case "IMPORT":
                userSeleccion = fileChooser.showOpenDialog(null);
                break;
        }
        
        if (userSeleccion != JFileChooser.APPROVE_OPTION){
            JOptionPane.showMessageDialog(null, "ruta no seleccionada");
            return null;
        }
        String ruta = fileChooser.getSelectedFile().getAbsolutePath();
        if (!ruta.endsWith(".txt")) ruta += ".txt";  
        return ruta;
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MENU_TABS = new javax.swing.JTabbedPane();
        TAB_LISTA = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_usuarios = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txt_buscar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cmb_tipo_busqueda = new javax.swing.JComboBox<>();
        btn_eliminar = new javax.swing.JButton();
        btn_registrar = new javax.swing.JButton();
        btn_importar = new javax.swing.JButton();
        btn_exportar = new javax.swing.JButton();
        TAB_FORM = new javax.swing.JPanel();
        label_titulo_formulario = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        label_error_numero = new javax.swing.JLabel();
        txt_numero_socio = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        label_error_nombre = new javax.swing.JLabel();
        btn_guardar = new javax.swing.JButton();
        txt_nombre = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TAB_LISTA.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel1.setText("Lista de Usuarios");
        TAB_LISTA.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 239, -1));

        table_usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table_usuarios);

        TAB_LISTA.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 760, 300));

        jLabel2.setText("Tipo de Busqueda:");
        TAB_LISTA.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 130, -1));

        txt_buscar.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txt_buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_buscarKeyReleased(evt);
            }
        });
        TAB_LISTA.add(txt_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 180, 30));

        jLabel3.setText("Buscar:");
        TAB_LISTA.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 70, -1));

        cmb_tipo_busqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TIPO", "CONCEPTO", "MONTO" }));
        TAB_LISTA.add(cmb_tipo_busqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 140, 30));

        btn_eliminar.setText("Eliminar");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 100, 90, 30));

        btn_registrar.setText("Registrar");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, 90, 30));

        btn_importar.setText("Importar");
        btn_importar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_importarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_importar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 60, 90, 30));

        btn_exportar.setText("Exportar");
        btn_exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exportarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_exportar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, 90, 30));

        MENU_TABS.addTab("Lista", TAB_LISTA);

        label_titulo_formulario.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        label_titulo_formulario.setText("Registrar Usuario");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel5.setText("Numero de Socio");

        label_error_numero.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel7.setText("Nombre");

        label_error_nombre.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N

        btn_guardar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TAB_FORMLayout = new javax.swing.GroupLayout(TAB_FORM);
        TAB_FORM.setLayout(TAB_FORMLayout);
        TAB_FORMLayout.setHorizontalGroup(
            TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_FORMLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(TAB_FORMLayout.createSequentialGroup()
                        .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(label_error_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(TAB_FORMLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(label_titulo_formulario, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 531, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TAB_FORMLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_guardar, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(TAB_FORMLayout.createSequentialGroup()
                        .addComponent(txt_numero_socio, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_error_numero, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(313, 313, 313))
        );
        TAB_FORMLayout.setVerticalGroup(
            TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_FORMLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(label_titulo_formulario)
                .addGap(32, 32, 32)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(label_error_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addGap(2, 2, 2)
                .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txt_numero_socio, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label_error_numero, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addComponent(btn_guardar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        MENU_TABS.addTab("Registro", TAB_FORM);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_buscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarKeyReleased
        // TODO add your handling code here:
        try {
            String valor = txt_buscar.getText();
            String tipo = String.valueOf(cmb_tipo_busqueda.getSelectedItem());
            buscarUsuario(valor, tipo);
        } catch (Exception e) {
            System.out.println("Error Busqueda: "+e.getMessage());
        }
    }//GEN-LAST:event_txt_buscarKeyReleased

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        // TODO add your handling code here:
        int fila = table_usuarios.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(null, "Usuario no seleccionado.");
            return;
        }
        String numero = String.valueOf(modeloTabla.getValueAt(fila, 2));
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Eliminar Usuario?","Cuidado!",JOptionPane.YES_NO_OPTION);
        if (numero != null && confirmacion == 0){
            System.out.println("codigo "+numero);
            UsuarioLink.eliminar(numero);
            JOptionPane.showMessageDialog(null, "Usuario eliminado.");
            mostrarTablaUsuarios();
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_exportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exportarActionPerformed
        // TODO add your handling code here:
        ExportarUsuarios();
    }//GEN-LAST:event_btn_exportarActionPerformed

    private void btn_importarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_importarActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btn_importarActionPerformed

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        // TODO add your handling code here:
        MENU_TABS.setSelectedComponent(TAB_FORM);
    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed
        label_error_nombre.setText("");
        label_error_numero.setText("");
        
        String nombre = String.valueOf(txt_nombre.getText());
        String numero = String.valueOf(txt_numero_socio.getText());
        int errores = 0;
        if (nombre.length() == 0){
            label_error_nombre.setText("Nombre requerido!");
            errores++;
        }
        if (numero.length() == 0){
            label_error_numero.setText("Numero de Socio requerido!");
            errores++;
        }
        
        if (errores > 0){ return; }
        
        UsuarioLink.agregar(nombre, numero);
        JOptionPane.showMessageDialog(null, "Usuario Agregado!");
        
        txt_nombre.setText("");
        txt_numero_socio.setText("");
        label_error_nombre.setText("");
        label_error_numero.setText("");
        
        MENU_TABS.setSelectedComponent(TAB_LISTA);
        mostrarTablaUsuarios();
    }//GEN-LAST:event_btn_guardarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI_Usuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane MENU_TABS;
    private javax.swing.JPanel TAB_FORM;
    private javax.swing.JPanel TAB_LISTA;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_exportar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_importar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.JComboBox<String> cmb_tipo_busqueda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_error_nombre;
    private javax.swing.JLabel label_error_numero;
    private javax.swing.JLabel label_titulo_formulario;
    private javax.swing.JTable table_usuarios;
    private javax.swing.JTextField txt_buscar;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_numero_socio;
    // End of variables declaration//GEN-END:variables
}
