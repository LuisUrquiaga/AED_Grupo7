/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import Arreglos.MovimientoArray;
import Clases.Movimiento;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;


public class GUI_movimientos extends javax.swing.JFrame {

    private DefaultTableModel modeloTabla = new DefaultTableModel();
    private int tamañoArray = 20;
    private MovimientoArray MovimientoArray = new MovimientoArray(tamañoArray);
    private String FORM_ACCION = "REGISTRO";
    private static Movimiento[] ListaMovimientos;
    
    public GUI_movimientos() {
        initComponents();
        
        this.setLocationRelativeTo(null);
        MovimientoArray.agregar(new Movimiento("Pago de Recibo de Luz","SALIDA",50.0));
        MovimientoArray.agregar(new Movimiento("Sueldo Mensual","ENTRADA",300.0));
        MovimientoArray.agregar(new Movimiento("Internet","SALIDA",65.0));
        
        mostrarTablaMovimientos();
    }

    
    // METODOS
    public void mostrarTablaMovimientos(){
        try {
            String columnas[] = {"Codigo","Concepto", "Tipo", "Monto"};
            modeloTabla.setColumnIdentifiers(columnas);
            modeloTabla.setRowCount(0);
            table_movimientos.setModel(modeloTabla);
            
            Movimiento[] data = MovimientoArray.obtenerLista();
            ListaMovimientos = data;
            
            for (int i=0; i<data.length; i++){
                if (data[i] == null){
                    continue;
                }
                int codigo = data[i].getId();
                String concepto = data[i].getConcepto();
                String tipo = data[i].getTipo();
                Double monto = data[i].getMonto();
                modeloTabla.addRow(new Object[]{codigo, concepto, tipo, monto});
            }
        } catch (Exception e) {
            System.out.println("Error Listado: "+e.getMessage());
        }
    }
    
    private void buscarMovimiento(String valor, String tipo_busqueda){
        modeloTabla.setRowCount(0);
        table_movimientos.setModel(modeloTabla);
        
        for (Movimiento movimiento: MovimientoArray.obtenerLista()){
            if (movimiento == null){
                continue;
            }
            int codigo = movimiento.getId();
            String concepto = movimiento.getConcepto();
            String tipo = movimiento.getTipo();
            Double monto = movimiento.getMonto();
            valor = valor.toUpperCase();
            switch (tipo_busqueda) {
                case "CONCEPTO":
                    if (concepto.toUpperCase().startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,concepto,tipo,monto });
                    }
                    break;
                case "TIPO":
                    if (tipo.toUpperCase().startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,concepto,tipo,monto });
                    }
                    break;
                case "MONTO":
                    if (String.valueOf(monto).startsWith(valor)){
                        modeloTabla.addRow(new Object[]{ codigo,concepto,tipo,monto });
                    }
                    break;
                default:
                    //throw new AssertionError();
            }
            
            
        }
    }
    
    
    
    public void ExportarMovimientos(){        
        Movimiento[] movimientos = MovimientoArray.obtenerLista();
        if (MovimientoArray.obtenerElementosValidos()== 0){
            JOptionPane.showMessageDialog(null,"No hay datos que exportar");
            return;
        }
        int cantidad = 0;
        String ruta = ElegirRuta("EXPORT");
        if (ruta == null){
            return;
        }
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for(Movimiento movimiento: movimientos){
                if (movimiento != null){
                    System.out.println(""+movimiento.getConcepto());
                    int codigo = movimiento.getId();
                    String concepto = movimiento.getConcepto();
                    String tipo = movimiento.getTipo();
                    Double monto = movimiento.getMonto();

                    String cadena_exportacion = 
                            codigo +" -> "+ 
                            concepto +" -> "+ 
                            tipo +" -> "+
                            monto;
                    escritor.write( cadena_exportacion +"\n");
                    cantidad++;
                }
            }             
            JOptionPane.showMessageDialog(null,"Proceso Completado. ("+ cantidad +") movimientos exportados.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error: "+e.getMessage());
        }
    }
    public void ImportarMovimientos(){
       String ruta = ElegirRuta("IMPORT");
        if (ruta == null){
            return;
        }
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            MovimientoArray.limpiarLista();
            int cantidad = 0;
            int index = 0;
            int indiceImportado = 0;
            while((linea = lector.readLine()) != null && cantidad < tamañoArray){
                String[] data = linea.split(" -> ");
                if (data.length != 4){
                    System.out.println(index+": fila no valida");
                    index++;
                    continue;
                }
                int codigo = Integer.parseInt(data[0].replace(" ",""));
                String concepto = String.valueOf(data[1]);
                String tipo = String.valueOf(data[2]);
                Double monto = Double.valueOf(data[3]);

                MovimientoArray.crearMovimiento(indiceImportado, new Movimiento(
                    concepto,tipo,monto
                ));
                indiceImportado++;
                cantidad++;
                
                index++;
            }
            mostrarTablaMovimientos();
            JOptionPane.showMessageDialog(null, "Proceso Completado. ("+cantidad+") movimientos importados.");
        } catch (IOException e) {
            System.out.println("err");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e.getMessage());
        } 
    }
    public String ElegirRuta(String tipo){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setPreferredSize(new Dimension(600, 450));
        fileChooser.setDialogTitle("Seleccione directorio");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de texto (.txt)","txt");
        fileChooser.setFileFilter(filter);
        fileChooser.setSelectedFile(new File("movimientos.txt"));
        int userSeleccion = 0;
        switch(tipo){
            case "EXPORT":
                userSeleccion = fileChooser.showSaveDialog(null);
                break;
            case "IMPORT":
                userSeleccion = fileChooser.showOpenDialog(null);
                break;
        }
        
        if (userSeleccion != JFileChooser.APPROVE_OPTION){
            JOptionPane.showMessageDialog(null, "ruta no seleccionada");
            return null;
        }
        String ruta = fileChooser.getSelectedFile().getAbsolutePath();
        if (!ruta.endsWith(".txt")) ruta += ".txt";  
        return ruta;
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MENU_TABS = new javax.swing.JTabbedPane();
        TAB_LISTA = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_movimientos = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txt_buscar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cmb_tipo_busqueda = new javax.swing.JComboBox<>();
        btn_eliminar = new javax.swing.JButton();
        btn_registrar = new javax.swing.JButton();
        btn_importar = new javax.swing.JButton();
        btn_editar = new javax.swing.JButton();
        btn_exportar = new javax.swing.JButton();
        TAB_FORM = new javax.swing.JPanel();
        label_titulo_formulario = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_tipo = new javax.swing.JComboBox<>();
        label_error_concepto = new javax.swing.JLabel();
        txt_concepto = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        label_error_tipo = new javax.swing.JLabel();
        label_error_monto = new javax.swing.JLabel();
        txt_monto = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_guardar = new javax.swing.JButton();
        txt_codigo = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TAB_LISTA.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel1.setText("Lista de Movimientos");
        TAB_LISTA.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 239, -1));

        table_movimientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table_movimientos);

        TAB_LISTA.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 760, 300));

        jLabel2.setText("Tipo de Busqueda:");
        TAB_LISTA.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 130, -1));

        txt_buscar.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txt_buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_buscarKeyReleased(evt);
            }
        });
        TAB_LISTA.add(txt_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 180, 30));

        jLabel3.setText("Buscar:");
        TAB_LISTA.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 70, -1));

        cmb_tipo_busqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TIPO", "CONCEPTO", "MONTO" }));
        TAB_LISTA.add(cmb_tipo_busqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 140, 30));

        btn_eliminar.setText("Eliminar");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 100, 90, 30));

        btn_registrar.setText("Registrar");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 100, 90, 30));

        btn_importar.setText("Importar");
        btn_importar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_importarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_importar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 60, 90, 30));

        btn_editar.setText("Editar");
        btn_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 100, 90, 30));

        btn_exportar.setText("Exportar");
        btn_exportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exportarActionPerformed(evt);
            }
        });
        TAB_LISTA.add(btn_exportar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 60, 90, 30));

        MENU_TABS.addTab("Lista", TAB_LISTA);

        label_titulo_formulario.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        label_titulo_formulario.setText("Registrar Movimiento");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel5.setText("Concepto:");

        txt_tipo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_tipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---", "ENTRADA", "SALIDA" }));
        txt_tipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_tipoActionPerformed(evt);
            }
        });

        label_error_concepto.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel7.setText("Tipo de Movimiento:");

        label_error_tipo.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N

        label_error_monto.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel6.setText("Monto:");

        btn_guardar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TAB_FORMLayout = new javax.swing.GroupLayout(TAB_FORM);
        TAB_FORM.setLayout(TAB_FORMLayout);
        TAB_FORMLayout.setHorizontalGroup(
            TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_FORMLayout.createSequentialGroup()
                .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TAB_FORMLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(txt_tipo, 0, 247, Short.MAX_VALUE))
                    .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txt_monto, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                        .addComponent(txt_concepto)))
                .addGap(499, 499, 499))
            .addGroup(TAB_FORMLayout.createSequentialGroup()
                .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TAB_FORMLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(TAB_FORMLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(TAB_FORMLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(label_error_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(TAB_FORMLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(label_error_concepto, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btn_guardar, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(label_error_monto, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(TAB_FORMLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(label_titulo_formulario, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txt_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        TAB_FORMLayout.setVerticalGroup(
            TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_FORMLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(TAB_FORMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_titulo_formulario)
                    .addComponent(txt_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(jLabel7)
                .addGap(2, 2, 2)
                .addComponent(txt_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label_error_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addGap(2, 2, 2)
                .addComponent(txt_concepto, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label_error_concepto, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addGap(2, 2, 2)
                .addComponent(txt_monto, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(label_error_monto, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(btn_guardar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        MENU_TABS.addTab("Registro", TAB_FORM);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MENU_TABS, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_buscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_buscarKeyReleased
        // TODO add your handling code here:
        try {
            String valor = txt_buscar.getText();
            String tipo = String.valueOf(cmb_tipo_busqueda.getSelectedItem());
            buscarMovimiento(valor, tipo);
        } catch (Exception e) {
            System.out.println("Error Busqueda: "+e.getMessage());
        }
    }//GEN-LAST:event_txt_buscarKeyReleased

    private void btn_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarActionPerformed
        // TODO add your handling code here:
        int fila = table_movimientos.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(null, "Registro no seleccionado");
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        Movimiento MovimientoData = MovimientoArray.obtenerMovimiento(codigo);
        if (MovimientoData == null){
            JOptionPane.showMessageDialog(null, "Registro no encontrado.");
            return;
        }
        txt_codigo.setText(String.valueOf(MovimientoData.getId()));
        txt_concepto.setText(MovimientoData.getConcepto());
        txt_tipo.setSelectedItem(MovimientoData.getTipo());
        txt_monto.setText(String.valueOf(MovimientoData.getMonto()));
                
        FORM_ACCION = "EDICION";
        label_titulo_formulario.setText("Edicion de Movimiento");
        
        MENU_TABS.setSelectedComponent(TAB_FORM);
    }//GEN-LAST:event_btn_editarActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        // TODO add your handling code here:
        int fila = table_movimientos.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(null, "Registro no seleccionado.");
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Eliminar Registro?","Cuidado!",JOptionPane.YES_NO_OPTION);
        if (confirmacion == 0){
            MovimientoArray.eliminar(codigo);
            JOptionPane.showMessageDialog(null, "Registro eliminado.");
            mostrarTablaMovimientos();
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_exportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exportarActionPerformed
        // TODO add your handling code here:
        ExportarMovimientos();
    }//GEN-LAST:event_btn_exportarActionPerformed

    private void btn_importarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_importarActionPerformed
        // TODO add your handling code here:
        ImportarMovimientos();
    }//GEN-LAST:event_btn_importarActionPerformed

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        // TODO add your handling code here:
        MENU_TABS.setSelectedComponent(TAB_FORM);
    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed
        // TODO add your handling code here:
        label_titulo_formulario.setText("");
        if (MovimientoArray.obtenerElementosValidos() == tamañoArray){
            JOptionPane.showMessageDialog(null, "Se ha llegado al Limite maximo de registros.");
            return;
        }
        
        String concepto = String.valueOf(txt_concepto.getText());
        String tipo = String.valueOf(txt_tipo.getSelectedItem());
        Double monto = Double.parseDouble(txt_monto.getText());
        int errores = 0;
        if (concepto.trim().isEmpty()){
            label_error_concepto.setText("Concepto requerido!");
            errores++;
        }
        if (tipo.trim().isEmpty()){
            label_error_tipo.setText("Tipo requerido!");
            errores++;
        }
        if (monto <= 0){
            label_error_monto.setText("Monto requerido!");
            errores++;
        }
        
        if (errores > 0){ return; }
        
        String mensaje = "***";
        Movimiento MovimientoGuardar = new Movimiento();
        
        
        if (FORM_ACCION.equals("REGISTRO")){
            
            MovimientoGuardar = new Movimiento(concepto, tipo, monto);
            MovimientoArray.agregar(MovimientoGuardar);
            mensaje = "Moviento guardado con exito.";
        
        }else if (FORM_ACCION.equals("EDICION")) {
            MovimientoGuardar.setId(Integer.parseInt(txt_codigo.getText()));
            MovimientoGuardar.setConcepto(txt_concepto.getText());
            MovimientoGuardar.setTipo(String.valueOf(txt_tipo.getSelectedItem()));
            MovimientoGuardar.setMonto(Double.parseDouble(txt_monto.getText()));
            MovimientoArray.editar(MovimientoGuardar);
            mensaje = "Movimiento actualizado!";
        }
        
        txt_codigo.setText("");
        txt_concepto.setText("");
        txt_tipo.setSelectedIndex(0);
        txt_monto.setText("");
        label_titulo_formulario.setText("Registrar Movimiento");
        FORM_ACCION = "REGISTRO";
        
        JOptionPane.showMessageDialog(null, mensaje);
        mostrarTablaMovimientos();
        MENU_TABS.setSelectedComponent(TAB_LISTA);
    }//GEN-LAST:event_btn_guardarActionPerformed

    private void txt_tipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_tipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_tipoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_movimientos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI_movimientos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane MENU_TABS;
    private javax.swing.JPanel TAB_FORM;
    private javax.swing.JPanel TAB_LISTA;
    private javax.swing.JButton btn_editar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_exportar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JButton btn_importar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.JComboBox<String> cmb_tipo_busqueda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_error_concepto;
    private javax.swing.JLabel label_error_monto;
    private javax.swing.JLabel label_error_tipo;
    private javax.swing.JLabel label_titulo_formulario;
    private javax.swing.JTable table_movimientos;
    private javax.swing.JTextField txt_buscar;
    private javax.swing.JTextField txt_codigo;
    private javax.swing.JTextField txt_concepto;
    private javax.swing.JTextField txt_monto;
    private javax.swing.JComboBox<String> txt_tipo;
    // End of variables declaration//GEN-END:variables
}
