package Clases;

import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Movimiento {
    String concepto;
    String tipo;
    Double monto;
    int id;

    public Movimiento(String concepto, String tipo, Double monto) {
        this.concepto = concepto;
        this.tipo = tipo;
        this.monto = monto;
        this.id = generarID();
    }
    
    public Movimiento(){}

    public int generarID(){
        Random random = new Random();
        // genera un numero de 6 digitos
        int id = random.nextInt(1000000);
        return id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }
    
    
}
