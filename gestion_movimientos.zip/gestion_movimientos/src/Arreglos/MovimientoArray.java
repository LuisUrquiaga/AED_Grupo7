/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import Clases.Movimiento;
import java.util.Arrays;


public class MovimientoArray {
    int indice;
    int tamaño;
    Movimiento[] Lista; 
    
    public MovimientoArray(int tamaño){
        this.tamaño = tamaño;
        indice = 0;
        Lista = new Movimiento[this.tamaño];
    }
    
    
    public int obtenerIndice(){
        return this.indice;
    }
    
    public void establecerIndice(int indice){
        this.indice = indice;
    }
    
    public int obtenerIndiceVacio(){
        int ind = this.obtenerElementosValidos() + 1;
        return ind;
    }
    
    public Movimiento[] obtenerLista(){
        return Lista;
    }
    
    public Movimiento obtenerMovimiento(int id){
        for (int i=0; i<Lista.length; i++){
            if (Lista[i] != null && Lista[i].getId() == id){
                return Lista[i];
            }
        }
        return null;
    }
    
    public int obtenerIndicePorID(int id){
        int indice = -1;
        for (int i=0; i<Lista.length; i++){
            if (Lista[i] != null && Lista[i].getId() == id){
                indice = i;
            }
        }
        return indice;
    }
    
    public void llenarLista(Movimiento[] Lista){
        this.Lista = Lista;
    }
    
    public void agregar(Movimiento movimiento){
        Lista[indice] = movimiento;
        indice++;
    }
    
    public boolean editar(Movimiento movimiento){
        int indice = this.obtenerIndicePorID(movimiento.getId());
        if (indice == -1) {return false;}
        
        String nuevo_concepto = movimiento.getConcepto();
        String nuevo_tipo = movimiento.getTipo();
        Double nuevo_monto = movimiento.getMonto();
        Lista[indice].setConcepto(nuevo_concepto);
        Lista[indice].setTipo(nuevo_tipo);
        Lista[indice].setMonto(nuevo_monto);
        return true;
    }
    
    public void eliminar(int id){
        Movimiento[] new_array = new Movimiento[this.tamaño];
        int new_index = 0;
        for(int i=0; i<Lista.length; i++){
            if (Lista[i] != null && Lista[i].getId()!= id){
                //Lista[i].setCodigo(new_index + 1);
                new_array[new_index] = Lista[i];
                //new_index++;
            }
        }
        Lista = new_array;
        //establecerIndice(new_index);
        
    }
    
    public void limpiarLista(){
        Arrays.fill(Lista, null);
    }
    
    // obtener elementos de tipo 'Libro' que no sean vacios o nulos
    public int obtenerElementosValidos(){
        int validos = 0;
        for (Movimiento movimiento: Lista){
            if (movimiento != null){
                validos++;
            }
        }
        return validos;
    }
    
    public void crearMovimiento(int index, Movimiento movimiento){
        System.out.println("IN: "+index);
        Lista[index] = movimiento;
    }
    
    
    
}
