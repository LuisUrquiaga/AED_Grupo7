package Clases;

public class Presupuesto {
    private String nombre;
    private String categoria;
    private double monto;

    public Presupuesto(String nombre, String categoria, double monto) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.monto = monto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getMonto() {
        return monto;
    }
    public Object[] toTableRow() {
        return new Object[]{this.nombre, this.categoria, this.monto};
    }
}

