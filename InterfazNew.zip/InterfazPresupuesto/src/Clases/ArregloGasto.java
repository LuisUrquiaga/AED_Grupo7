package Clases;
public class ArregloGasto {
    private Presupuesto[] gastos;
    private int indice;

    public ArregloGasto(int tam) {
        indice = 0;
        gastos = new Presupuesto[tam];
    }

    public int getIndice() {
        return indice;
    }

    public void add(Presupuesto gasto) {
        if (indice < gastos.length) {
            gastos[indice] = gasto;
            indice++;
        } else {
            System.out.println("No se pueden agregar más gastos, el arreglo está lleno.");
        }
    }

    public Presupuesto[] getGastos() {
        return gastos;
    }

    public Presupuesto getGasto(int pos) {
        if (pos >= 0 && pos < indice) {
            return gastos[pos];
        } else {
            return null; // Retorna null si la posición es inválida
        }
    }
}
