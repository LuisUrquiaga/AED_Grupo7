
package Clases;

public class NodoArbolPresupuesto {
    String dato;
    NodoArbolPresupuesto izquierda;
    NodoArbolPresupuesto derecha;

    public NodoArbolPresupuesto(String valor){
        this.dato = valor;
        this.izquierda = null;
        this.derecha = null;
    }
}
