package Clases;
public class NodoPresupuesto {
    private Presupuesto presupuesto;  
    private NodoPresupuesto siguiente;  

    
    public NodoPresupuesto(Presupuesto presupuesto) {
        this.presupuesto = presupuesto;
        this.siguiente = null;
    }

    
    public Presupuesto getPresupuesto() {
        return presupuesto;
    }

    
    public void setPresupuesto(Presupuesto presupuesto) {
        this.presupuesto = presupuesto;
    }

  
    public NodoPresupuesto getSiguiente() {
        return siguiente;
    }

    
    public void setSiguiente(NodoPresupuesto siguiente) {
        this.siguiente = siguiente;
    }
}
