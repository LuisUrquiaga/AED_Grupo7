package Clases;
import Clases.NodoPresupuesto;
import javax.swing.table.DefaultTableModel;

public class ListaPresupuesto {
    private NodoPresupuesto cabeza;

    public ListaPresupuesto() {
        this.cabeza = null;
    }

    // Método para agregar un nuevo presupuesto
    public void agregar(Presupuesto presupuesto) {
        NodoPresupuesto nuevoNodo = new NodoPresupuesto(presupuesto);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            NodoPresupuesto actual = cabeza;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevoNodo);
        }
    }




public Presupuesto buscar(String nombre) {
    NodoPresupuesto actual = cabeza;
    nombre = nombre.toLowerCase(); 

    while (actual != null) {
        Presupuesto presupuesto = actual.getPresupuesto();
     
        if (presupuesto.getNombre().toLowerCase().contains(nombre) || 
            presupuesto.getCategoria().toLowerCase().contains(nombre) || 
            String.valueOf(presupuesto.getMonto()).contains(nombre)) {
            return presupuesto; 
        }
        actual = actual.getSiguiente();
    }
    return null; 
}

  
    


    public void listar(DefaultTableModel modelo) {
        modelo.setRowCount(0); 
        NodoPresupuesto actual = cabeza;
        while (actual != null) {
            modelo.addRow(actual.getPresupuesto().toTableRow());
            actual = actual.getSiguiente();
        }
    }

 
    public void ordenar() {
        if (cabeza == null || cabeza.getSiguiente() == null) {
            return; 
        }

        boolean intercambiado;
        do {
            intercambiado = false;
            NodoPresupuesto actual = cabeza;

            while (actual.getSiguiente() != null) {
                NodoPresupuesto siguiente = actual.getSiguiente();
             
                if (actual.getPresupuesto().getNombre().compareToIgnoreCase(siguiente.getPresupuesto().getNombre()) > 0) {

                    Presupuesto temp = actual.getPresupuesto();
                    actual.setPresupuesto(siguiente.getPresupuesto());
                    siguiente.setPresupuesto(temp);
                    intercambiado = true;
                }
                actual = actual.getSiguiente();
            }
        } while (intercambiado);
    }

    public boolean eliminarGasto(String nombreGasto, DefaultTableModel modelo) {
    if (cabeza == null) return false; // Lista vacía, no hay nada que eliminar.

    NodoPresupuesto actual = cabeza;
    NodoPresupuesto anterior = null;
    boolean eliminado = false;

    nombreGasto = nombreGasto.toLowerCase(); // Comparación case-insensitive

    while (actual != null) {
        if (actual.getPresupuesto().getNombre().toLowerCase().equals(nombreGasto)) {
            if (anterior == null) {
                cabeza = actual.getSiguiente(); // Eliminar primer nodo
            } else {
                anterior.setSiguiente(actual.getSiguiente()); // Saltar el nodo actual
            }
            eliminado = true;
            break;
        }
        anterior = actual;
        actual = actual.getSiguiente();
    }

    if (eliminado) {
        listar(modelo); // Actualizar la tabla
    }
    return eliminado; // Devuelve true si se eliminó, false si no.
}

    public int getCantidadGastos() {
    int contador = 0;
    NodoPresupuesto actual = cabeza;
    while (actual != null) {
        contador++;
        actual = actual.getSiguiente();
    }
    return contador;
}
public NodoPresupuesto getCabeza() {
    return cabeza;
}


}
