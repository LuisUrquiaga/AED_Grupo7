package Clases;



public class NodoColaPresupuesto {
    private Presupuesto dato;
    private NodoColaPresupuesto siguiente;

    public NodoColaPresupuesto(Presupuesto dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    public Presupuesto getPresupuesto() {
        return dato;
    }
    
    public Presupuesto getDato() {
        return dato;
    }

    public void setDato(Presupuesto dato) {
        this.dato = dato;
    }
    
    public void setSiguiente(NodoColaPresupuesto siguiente) {
        this.siguiente = siguiente;
    }

    public NodoColaPresupuesto getSiguiente() {
        return siguiente;
    }
}
