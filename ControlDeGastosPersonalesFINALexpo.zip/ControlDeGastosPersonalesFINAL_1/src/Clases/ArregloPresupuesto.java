package Clases;

public class ArregloPresupuesto {
    private double ingresos;
    private Presupuesto[] gastos; // Arreglo de gastos
    private int indice; // Contador de la posición actual en el arreglo

    public ArregloPresupuesto(double ingresos, int capacidad) {
        this.ingresos = ingresos;
        this.gastos = new Presupuesto[capacidad];
        this.indice = 0;
    }

    public void agregarGasto(String nombre, double monto, String categoria) {
        // Validaciones
       if (nombre == null || nombre.trim().isEmpty()) {
        throw new IllegalArgumentException("El nombre del gasto no puede estar vacío.");
    }
    if (categoria == null || categoria.trim().isEmpty()) {
        throw new IllegalArgumentException("La categoría no puede estar vacía.");
    }
    if (monto <= 0) {
        throw new IllegalArgumentException("El monto debe ser mayor que cero.");
    }

    // Verifica si el nuevo gasto no excede el presupuesto
    double totalGastos = calcularTotalGastos();
    if (totalGastos + monto > ingresos) {
        throw new IllegalStateException("El gasto excede el presupuesto disponible. Gastos actuales: $" + totalGastos + ", Ingresos: $" + ingresos);
    }

    if (indice < gastos.length) { // Verifica que haya espacio en el arreglo
        gastos[indice] = new Presupuesto(nombre, categoria, monto); // Crea un nuevo Presupuesto y lo agrega
        indice++;
    } else {
        throw new IllegalStateException("No se pueden agregar más gastos. Capacidad alcanzada.");
    }
    }

    public void eliminarGasto(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del gasto no puede estar vacío.");
        }

        boolean encontrado = false;

        for (int i = 0; i < indice; i++) {
            if (gastos[i].getNombre().equalsIgnoreCase(nombre)) { // Compara ignorando mayúsculas/minúsculas
                // Eliminar el gasto y reorganizar el arreglo
                for (int j = i; j < indice - 1; j++) {
                    gastos[j] = gastos[j + 1];
                }
                gastos[indice - 1] = null; // Limpia el último elemento
                indice--;
                encontrado = true;
                break; // Salimos después de eliminar
            }
        }

        if (!encontrado) {
            throw new IllegalArgumentException("Gasto no encontrado.");
        }
    }

    public double calcularTotalGastos() {
        double total = 0;
        for (int i = 0; i < indice; i++) {
            total += gastos[i].getMonto();
        }
        return total;
    }

    public double calcularAhorro() {
        return ingresos - calcularTotalGastos();
    }

    public String mostrarPresupuesto() {
        StringBuilder resumen = new StringBuilder("Resumen del Presupuesto:\n");
        resumen.append("Ingresos: ").append(ingresos).append("\n");
        resumen.append("Gastos:\n");
        for (int i = 0; i < indice; i++) {
            resumen.append(gastos[i].getNombre()).append(" - ").append(gastos[i].getCategoria()).append(": $").append(gastos[i].getMonto()).append("\n");
        }
        resumen.append("Total de Gastos: ").append(calcularTotalGastos()).append("\n");
        resumen.append("Ahorro: ").append(calcularAhorro()).append("\n");
        return resumen.toString();
    }

    public Presupuesto[] getGastos() {
        return gastos;
    }

    public int getCantidadGastos() {
        return indice;
    }
}
