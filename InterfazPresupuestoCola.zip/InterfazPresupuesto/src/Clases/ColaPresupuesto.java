
package Clases;

import javax.swing.table.DefaultTableModel;

public class ColaPresupuesto {
    private NodoColaPresupuesto frente;
    private NodoColaPresupuesto finalCola;

    public ColaPresupuesto() {
        frente = finalCola = null;
    }
    
   public void encolar(Presupuesto presupuesto) {
        NodoColaPresupuesto nuevoNodo = new NodoColaPresupuesto(presupuesto);
        if (frente == null) {
            frente = nuevoNodo;
            finalCola = nuevoNodo;
        } else {
            finalCola.setSiguiente(nuevoNodo);
            finalCola = nuevoNodo;
        }
    }
    
     public Presupuesto buscar(String valorBusqueda) {
    NodoColaPresupuesto actual = frente;
    valorBusqueda = valorBusqueda.toLowerCase();

    while (actual != null) {
        Presupuesto presupuesto = actual.getPresupuesto();

        if (presupuesto.getNombre().toLowerCase().contains(valorBusqueda) ||
            presupuesto.getCategoria().toLowerCase().contains(valorBusqueda) ||
            String.valueOf(presupuesto.getMonto()).toLowerCase().contains(valorBusqueda)) {
            return presupuesto;
        }
        actual = actual.getSiguiente();
    }
    return null;
}

     
      public void listar(DefaultTableModel modelo) {
        modelo.setRowCount(0);
        NodoColaPresupuesto actual = frente;
        while (actual != null) {
            modelo.addRow(actual.getPresupuesto().toTableRow());
            actual = actual.getSiguiente();
        }
    }
      
     public void ordenar() {
        if (frente == null || frente.getSiguiente() == null) {
        return;
    }

    boolean intercambiado;
    do {
        intercambiado = false;
        NodoColaPresupuesto actual = frente;
        NodoColaPresupuesto anterior = null;

        while (actual != null && actual.getSiguiente() != null) {
            NodoColaPresupuesto siguiente = actual.getSiguiente();


            String nombreActual = actual.getPresupuesto().getNombre();
            String nombreSiguiente = siguiente.getPresupuesto().getNombre();

            if (nombreActual != null && nombreSiguiente != null &&
                nombreActual.compareTo(nombreSiguiente) > 0) {
                

                if (anterior == null) {
                    frente = siguiente; 
                } else {
                    anterior.setSiguiente(siguiente);
                }
                actual.setSiguiente(siguiente.getSiguiente());
                siguiente.setSiguiente(actual);
                intercambiado = true;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        }
    } while (intercambiado);
}
}
