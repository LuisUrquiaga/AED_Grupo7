package GUI;

import EDD.ColaConcepto;
import Clases.Concepto;
import EDD.NodoColaConcepto;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import javax.swing.JPanel;
import javax.swing.*;

    public class FrmColaConcepto extends javax.swing.JFrame {
    private ColaConcepto colaConceptos;
    private CardLayout cardLayout;
    
    public FrmColaConcepto() {
        initComponents();
        ColaConcepto colaConceptos = new ColaConcepto();
        cardLayout = new CardLayout();
        JPanel contenedorPaneles = new JPanel(cardLayout);

        contenedorPaneles.add(JpRegistro, "JpRegistro");
        contenedorPaneles.add(JpLista, "JpLista");

        getContentPane().add(contenedorPaneles);    
        pack();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        JtableConcepto = new javax.swing.JTabbedPane();
        JpLista = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        BtnMenu = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ComboBuscar = new javax.swing.JComboBox<>();
        ComboMonto = new javax.swing.JComboBox<>();
        btnBuscarLista = new javax.swing.JButton();
        BtnActualizarLista = new javax.swing.JButton();
        BtnEliminarLista = new javax.swing.JButton();
        BtnRegistrarLista = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        JtablaLista = new javax.swing.JTable();
        BtnOrdernarLista = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        ComboOrden = new javax.swing.JComboBox<>();
        JpRegistro = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        TxtMonto = new javax.swing.JTextField();
        ComboCategoria = new javax.swing.JComboBox<>();
        TxtDescripcion = new javax.swing.JTextField();
        ComboMetododepago = new javax.swing.JComboBox<>();
        BtnRegistro = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        DateFecha = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel6.setBackground(new java.awt.Color(102, 204, 255));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Lista de Concepto");

        BtnMenu.setText("Menu");
        BtnMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(255, 255, 255)
                .addComponent(BtnMenu)
                .addGap(25, 25, 25))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(BtnMenu))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel1.setText("Selección:");

        jLabel2.setText("Dato:");

        ComboBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBuscarActionPerformed(evt);
            }
        });

        ComboMonto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboMontoActionPerformed(evt);
            }
        });

        btnBuscarLista.setText("Buscar");
        btnBuscarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarListaActionPerformed(evt);
            }
        });

        BtnActualizarLista.setText("Actualizar");
        BtnActualizarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActualizarListaActionPerformed(evt);
            }
        });

        BtnEliminarLista.setBackground(new java.awt.Color(255, 51, 102));
        BtnEliminarLista.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnEliminarLista.setText("Eliminar");
        BtnEliminarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarListaActionPerformed(evt);
            }
        });

        BtnRegistrarLista.setBackground(new java.awt.Color(51, 204, 255));
        BtnRegistrarLista.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnRegistrarLista.setText("Registrar");
        BtnRegistrarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistrarListaActionPerformed(evt);
            }
        });

        JtablaLista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Monto", "Categoria", "Fecha", "Descripción", "MetodoDePago"
            }
        ));
        jScrollPane1.setViewportView(JtablaLista);

        BtnOrdernarLista.setText("Ordenar");
        BtnOrdernarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnOrdernarListaActionPerformed(evt);
            }
        });

        jLabel13.setText("Oden:");

        ComboOrden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboOrdenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JpListaLayout = new javax.swing.GroupLayout(JpLista);
        JpLista.setLayout(JpListaLayout);
        JpListaLayout.setHorizontalGroup(
            JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(JpListaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpListaLayout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(JpListaLayout.createSequentialGroup()
                        .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel13)
                            .addComponent(jLabel2))
                        .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JpListaLayout.createSequentialGroup()
                                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(JpListaLayout.createSequentialGroup()
                                        .addGap(7, 7, 7)
                                        .addComponent(ComboOrden, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JpListaLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ComboMonto, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(BtnOrdernarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnBuscarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(JpListaLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(ComboBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(BtnActualizarLista)))
                        .addGap(83, 83, 83)
                        .addComponent(BtnRegistrarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 119, Short.MAX_VALUE)
                        .addComponent(BtnEliminarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(85, 85, 85))))
        );
        JpListaLayout.setVerticalGroup(
            JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JpListaLayout.createSequentialGroup()
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpListaLayout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BtnActualizarLista))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ComboBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(BtnEliminarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnRegistrarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ComboMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarLista))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ComboOrden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13))
                    .addComponent(BtnOrdernarLista))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        JtableConcepto.addTab("Lista", JpLista);

        jPanel8.setBackground(new java.awt.Color(102, 204, 255));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Registro de Concepto");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(286, 286, 286)
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel8)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Usuario");

        jLabel4.setText("Nombre:");

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        jLabel5.setText("Monto:");

        jLabel9.setText("Categoria:");

        jLabel10.setText("Descripcion:");

        jLabel11.setText("Fecha:");

        jLabel12.setText("MetodoDePago:");

        TxtMonto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtMontoActionPerformed(evt);
            }
        });

        ComboCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Electricidad", "Agua", "Terreno", "otros", " " }));
        ComboCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboCategoriaActionPerformed(evt);
            }
        });

        TxtDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtDescripcionActionPerformed(evt);
            }
        });

        ComboMetododepago.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Directo", "Tarjeta", " " }));
        ComboMetododepago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboMetododepagoActionPerformed(evt);
            }
        });

        BtnRegistro.setBackground(new java.awt.Color(204, 255, 255));
        BtnRegistro.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnRegistro.setText("Registrar");
        BtnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistroActionPerformed(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Conceptoo.png"))); // NOI18N

        DateFecha.setDateFormatString("dd/MM/YY");

        javax.swing.GroupLayout JpRegistroLayout = new javax.swing.GroupLayout(JpRegistro);
        JpRegistro.setLayout(JpRegistroLayout);
        JpRegistroLayout.setHorizontalGroup(
            JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(JpRegistroLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpRegistroLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(27, 27, 27)
                        .addComponent(TxtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JpRegistroLayout.createSequentialGroup()
                            .addComponent(jLabel11)
                            .addGap(58, 58, 58)
                            .addComponent(DateFecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JpRegistroLayout.createSequentialGroup()
                            .addComponent(jLabel9)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JpRegistroLayout.createSequentialGroup()
                            .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel5)
                                .addComponent(jLabel4))
                            .addGap(45, 45, 45)
                            .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(TxtMonto, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(JpRegistroLayout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboMetododepago, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 212, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(69, 69, 69))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JpRegistroLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(346, 346, 346))
            .addGroup(JpRegistroLayout.createSequentialGroup()
                .addGap(178, 178, 178)
                .addComponent(BtnRegistro)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        JpRegistroLayout.setVerticalGroup(
            JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JpRegistroLayout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(32, 32, 32)
                .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpRegistroLayout.createSequentialGroup()
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(TxtMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(ComboCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JpRegistroLayout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(31, 31, 31)
                                .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(TxtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10)))
                            .addComponent(DateFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(ComboMetododepago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel7))
                .addGap(31, 31, 31)
                .addComponent(BtnRegistro)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        JtableConcepto.addTab("Registro", JpRegistro);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JtableConcepto)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JtableConcepto)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnActualizarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActualizarListaActionPerformed
        // metodo ordenamiento burbuja
        if (camposCompletos()) {
            actualizarRegistro();
        }
            cargarDatosEnTabla();
            actualizarComboMonto(); 
            limpiarCampos();
    }//GEN-LAST:event_BtnActualizarListaActionPerformed

    
    private void BtnRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistroActionPerformed
        String nombre = txtNombre.getText();
        double monto = obtenerMonto();

        if (monto < 0) {
            JOptionPane.showMessageDialog(this, "El monto no puede ser negativo.");
            return;
        }

        String categoria = (String) ComboCategoria.getSelectedItem();
        Date fecha = DateFecha.getDate();
        String descripcion = TxtDescripcion.getText();
        String metodo_pago = (String) ComboMetododepago.getSelectedItem();

        Concepto nuevoConcepto = new Concepto(nombre, monto, categoria, fecha, descripcion, metodo_pago);
        colaConceptos.encolar(nuevoConcepto);

        cargarDatosEnTabla();
        cardLayout.show(getContentPane(), "JpLista");
    
    }//GEN-LAST:event_BtnRegistroActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        TxtMonto.requestFocus();
    }//GEN-LAST:event_txtNombreActionPerformed

    private void TxtMontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtMontoActionPerformed
        ComboCategoria.requestFocus();
    }//GEN-LAST:event_TxtMontoActionPerformed

    private void ComboCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboCategoriaActionPerformed

    }//GEN-LAST:event_ComboCategoriaActionPerformed

    private void TxtDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtDescripcionActionPerformed
         ComboMetododepago.requestFocus();
    }//GEN-LAST:event_TxtDescripcionActionPerformed

    private void ComboMetododepagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboMetododepagoActionPerformed
       
    }//GEN-LAST:event_ComboMetododepagoActionPerformed

    private void BtnMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnMenuActionPerformed
        FrmMenu menu = new FrmMenu();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BtnMenuActionPerformed

    private void BtnRegistrarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistrarListaActionPerformed
    JtableConcepto.setSelectedComponent(JpRegistro); 
    }//GEN-LAST:event_BtnRegistrarListaActionPerformed

    private void btnBuscarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarListaActionPerformed
        String valorSeleccionado = (String) ComboMonto.getSelectedItem();

        if (valorSeleccionado != null) {
            Concepto conceptoEncontrado = colaConceptos.buscar(valorSeleccionado);
            if (conceptoEncontrado != null) {
                JOptionPane.showMessageDialog(this, "Concepto encontrado: " + conceptoEncontrado.getNombre());
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró ningún concepto con el valor seleccionado.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un valor para buscar.");
        }
    }//GEN-LAST:event_btnBuscarListaActionPerformed

    private void BtnEliminarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarListaActionPerformed
        String valorBusqueda = JOptionPane.showInputDialog(this, "Ingrese el nombre del concepto a eliminar:");

        if (valorBusqueda != null && !valorBusqueda.isEmpty()) {
            Concepto conceptoEliminar = colaConceptos.buscar(valorBusqueda);

            if (conceptoEliminar != null) {
                // No existe un método directo para eliminar, por lo que debemos crear una lógica para "desencolar"
                NodoColaConcepto nodoActual = colaConceptos.getFrente();
                NodoColaConcepto nodoPrevio = null;

                while (nodoActual != null) {
                    if (nodoActual.getConcepto().getNombre().equals(valorBusqueda)) {
                        if (nodoPrevio == null) {  // Si es el primer nodo
                            colaConceptos.setFrente(nodoActual.getSiguiente());
                        } else {
                            nodoPrevio.setSiguiente(nodoActual.getSiguiente());
                        }
                        JOptionPane.showMessageDialog(this, "Concepto eliminado exitosamente.");
                        return;
                    }
                    nodoPrevio = nodoActual;
                    nodoActual = nodoActual.getSiguiente();
                }
                JOptionPane.showMessageDialog(this, "No se encontró el concepto para eliminar.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el concepto.");
            }
        }
    }//GEN-LAST:event_BtnEliminarListaActionPerformed

    private void ComboMontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboMontoActionPerformed

    }//GEN-LAST:event_ComboMontoActionPerformed

    private void ComboBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBuscarActionPerformed

    }//GEN-LAST:event_ComboBuscarActionPerformed

    private void BtnOrdernarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnOrdernarListaActionPerformed
         colaConceptos.ordenar();  
        cargarDatosEnTabla();
    }//GEN-LAST:event_BtnOrdernarListaActionPerformed

    private void ComboOrdenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboOrdenActionPerformed

    }//GEN-LAST:event_ComboOrdenActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            try {
                FrmColaConcepto frame = new FrmColaConcepto();
                frame.setVisible(true);  // Asegúrate de hacer visible la ventana
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnActualizarLista;
    private javax.swing.JButton BtnEliminarLista;
    private javax.swing.JButton BtnMenu;
    private javax.swing.JButton BtnOrdernarLista;
    private javax.swing.JButton BtnRegistrarLista;
    private javax.swing.JButton BtnRegistro;
    private javax.swing.JComboBox<String> ComboBuscar;
    private javax.swing.JComboBox<String> ComboCategoria;
    private javax.swing.JComboBox<String> ComboMetododepago;
    private javax.swing.JComboBox<String> ComboMonto;
    private javax.swing.JComboBox<String> ComboOrden;
    private com.toedter.calendar.JDateChooser DateFecha;
    private javax.swing.JPanel JpLista;
    private javax.swing.JPanel JpRegistro;
    private javax.swing.JTable JtablaLista;
    private javax.swing.JTabbedPane JtableConcepto;
    private javax.swing.JTextField TxtDescripcion;
    private javax.swing.JTextField TxtMonto;
    private javax.swing.JButton btnBuscarLista;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables

    private void actualizarComboMonto() {
    ComboMonto.removeAllItems();  
    NodoColaConcepto actual = colaConceptos.getFrente(); 

    while (actual != null) {
        ComboMonto.addItem(String.valueOf(actual.getConcepto().getMonto()));
        actual = actual.getSiguiente();  
    }
}

private void actualizarRegistro() {
    String nombre = txtNombre.getText();
    Concepto conceptoEncontrado = colaConceptos.buscar(nombre);

    if (conceptoEncontrado != null) {
        try {
            double monto = obtenerMonto(); 
            if (monto < 0) {
                JOptionPane.showMessageDialog(this, "El monto no puede ser negativo.");
                return;  
            }
            conceptoEncontrado.setMonto(monto);
            conceptoEncontrado.setCategoria((String) ComboCategoria.getSelectedItem());
            conceptoEncontrado.setFecha(DateFecha.getDate());
            conceptoEncontrado.setDescripcion(TxtDescripcion.getText());
            conceptoEncontrado.setMetodo_pago((String) ComboMetododepago.getSelectedItem());
            JOptionPane.showMessageDialog(this, "Registro actualizado con éxito.");
            actualizarComboMonto(); 
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Monto inválido.");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Concepto no encontrado.");
    }
}

    private void cargarDatosEnTabla() {
    DefaultTableModel modelo = (DefaultTableModel) JtablaLista.getModel();
    modelo.setRowCount(0); 

    colaConceptos.listar(modelo); 
    }

    private void registrarNuevoConcepto() {
    String nombre = txtNombre.getText();
    double monto = obtenerMonto();

    if (monto < 0) {
        JOptionPane.showMessageDialog(this, "El monto no puede ser negativo.");
        return;
    }

    String categoria = (String) ComboCategoria.getSelectedItem();
    Date fecha = DateFecha.getDate();
    String descripcion = TxtDescripcion.getText();
    String metodo_pago = (String) ComboMetododepago.getSelectedItem();

    Concepto nuevoConcepto = new Concepto(nombre, monto, categoria, fecha, descripcion, metodo_pago);
    colaConceptos.encolar(nuevoConcepto);  
    JOptionPane.showMessageDialog(this, "Concepto registrado con éxito.");

    cargarDatosEnTabla(); 
    }

    private void limpiarCampos() {
    txtNombre.setText("");
    TxtMonto.setText("");
    ComboCategoria.setSelectedIndex(0);
    DateFecha.setDate(null);
    TxtDescripcion.setText("");
    ComboMetododepago.setSelectedIndex(0);
    }   

    private double obtenerMonto() {
    try {
        return Double.parseDouble(TxtMonto.getText());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Por favor, ingrese un monto válido.");
        return -1;  
    }
    }

    private boolean camposCompletos() {

    if (txtNombre.getText().isEmpty() || TxtMonto.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
        return false;
    }
    return true;
    }

    private void buscarYActualizarTabla(String criterioSeleccionado, String valorSeleccionado) {
    DefaultTableModel modelo = (DefaultTableModel) JtablaLista.getModel();
    modelo.setRowCount(0);  

    NodoColaConcepto nodo = colaConceptos.getFrente();  
    while (nodo != null) {  
        Concepto concepto = nodo.getConcepto();
        if (coincideCriterio(concepto, criterioSeleccionado, valorSeleccionado)) {
            Object[] fila = {
                concepto.getNombre(),
                concepto.getMonto(),
                concepto.getCategoria(),
                concepto.getFecha(),
                concepto.getDescripcion(),
                concepto.getMetodo_pago()
            };
            modelo.addRow(fila);  
        }
        nodo = nodo.getSiguiente(); 
    }


    if (modelo.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No se encontraron coincidencias para los criterios seleccionados.");
    }
    }

    private boolean coincideCriterio(Concepto concepto, String criterio, String valor) {
    switch (criterio) {
        case "Nombre":
            return concepto.getNombre().equalsIgnoreCase(valor);
        case "Categoria":
            return concepto.getCategoria().equalsIgnoreCase(valor);
        case "Fecha":
            return concepto.getFecha().toString().contains(valor);
        case "Descripcion":
            return concepto.getDescripcion().contains(valor);
        case "MetodoDePago":
            return concepto.getMetodo_pago().equalsIgnoreCase(valor);
        case "Monto":
            try {
                return concepto.getMonto() == Double.parseDouble(valor);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese un monto válido.");
                return false;
            }
        default:
            return false;
    }
    }}