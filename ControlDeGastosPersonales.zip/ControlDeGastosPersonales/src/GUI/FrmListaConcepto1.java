package GUI;

import Clases.Concepto;
import EDD.ListaConcepto;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Date;

public class FrmListaConcepto1 extends javax.swing.JFrame {
    private ListaConcepto listaconceptos;
    private DefaultTableModel modelos;
    public FrmListaConcepto1() {
        initComponents();
        listaconceptos = new ListaConcepto();
        String[]columnas = {"Nombre", "Monto", "Categoria", "Fecha", "Descriptico","MetodoDePago"};
        modelos = new DefaultTableModel(columnas,0);
        JtablaLista.setModel(modelos);
        cargarDatosEnTabla();
        inicializarCombos();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        JtableConcepto = new javax.swing.JTabbedPane();
        JpLista = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        BtnMenu = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ComboBuscar = new javax.swing.JComboBox<>();
        ComboMonto = new javax.swing.JComboBox<>();
        btnBuscarLista = new javax.swing.JButton();
        BtnActualizarLista = new javax.swing.JButton();
        BtnEliminarLista = new javax.swing.JButton();
        BtnRegistrarLista = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        JtablaLista = new javax.swing.JTable();
        BtnOrdernarLista = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        ComboOrden = new javax.swing.JComboBox<>();
        JpRegistro = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        TxtMonto = new javax.swing.JTextField();
        ComboCategoria = new javax.swing.JComboBox<>();
        TxtDescripcion = new javax.swing.JTextField();
        ComboMetododepago = new javax.swing.JComboBox<>();
        BtnRegistro = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        DateFecha = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel6.setBackground(new java.awt.Color(102, 204, 255));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Lista de Concepto");

        BtnMenu.setText("Menu");
        BtnMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(255, 255, 255)
                .addComponent(BtnMenu)
                .addGap(25, 25, 25))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(BtnMenu))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel1.setText("Selección:");

        jLabel2.setText("Dato:");

        ComboBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBuscarActionPerformed(evt);
            }
        });

        ComboMonto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboMontoActionPerformed(evt);
            }
        });

        btnBuscarLista.setText("Buscar");
        btnBuscarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarListaActionPerformed(evt);
            }
        });

        BtnActualizarLista.setText("Actualizar");
        BtnActualizarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActualizarListaActionPerformed(evt);
            }
        });

        BtnEliminarLista.setBackground(new java.awt.Color(255, 51, 102));
        BtnEliminarLista.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnEliminarLista.setText("Eliminar");
        BtnEliminarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarListaActionPerformed(evt);
            }
        });

        BtnRegistrarLista.setBackground(new java.awt.Color(51, 204, 255));
        BtnRegistrarLista.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnRegistrarLista.setText("Registrar");
        BtnRegistrarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistrarListaActionPerformed(evt);
            }
        });

        JtablaLista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Monto", "Categoria", "Fecha", "Descripción", "MetodoDePago"
            }
        ));
        jScrollPane1.setViewportView(JtablaLista);

        BtnOrdernarLista.setText("Ordenar");
        BtnOrdernarLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnOrdernarListaActionPerformed(evt);
            }
        });

        jLabel13.setText("Oden:");

        ComboOrden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboOrdenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JpListaLayout = new javax.swing.GroupLayout(JpLista);
        JpLista.setLayout(JpListaLayout);
        JpListaLayout.setHorizontalGroup(
            JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(JpListaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpListaLayout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(JpListaLayout.createSequentialGroup()
                        .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel13)
                            .addComponent(jLabel2))
                        .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JpListaLayout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(ComboOrden, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ComboMonto, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(JpListaLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ComboBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JpListaLayout.createSequentialGroup()
                                .addComponent(BtnOrdernarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(83, 83, 83)
                                .addComponent(BtnRegistrarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 119, Short.MAX_VALUE)
                                .addComponent(BtnEliminarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(85, 85, 85))
                            .addGroup(JpListaLayout.createSequentialGroup()
                                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnBuscarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(BtnActualizarLista))
                                .addGap(0, 0, Short.MAX_VALUE))))))
        );
        JpListaLayout.setVerticalGroup(
            JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JpListaLayout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(ComboBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnActualizarLista))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(BtnEliminarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnRegistrarLista, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ComboMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarLista))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ComboOrden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13))
                    .addComponent(BtnOrdernarLista))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        JtableConcepto.addTab("Lista", JpLista);

        jPanel8.setBackground(new java.awt.Color(102, 204, 255));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Registro de Concepto");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(286, 286, 286)
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel8)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Usuario");

        jLabel4.setText("Nombre:");

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        jLabel5.setText("Monto:");

        jLabel9.setText("Categoria:");

        jLabel10.setText("Descripcion:");

        jLabel11.setText("Fecha:");

        jLabel12.setText("MetodoDePago:");

        TxtMonto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtMontoActionPerformed(evt);
            }
        });

        ComboCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Electricidad", "Agua", "Terreno", "otros", " " }));
        ComboCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboCategoriaActionPerformed(evt);
            }
        });

        TxtDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtDescripcionActionPerformed(evt);
            }
        });

        ComboMetododepago.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Directo", "Tarjeta", " " }));
        ComboMetododepago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboMetododepagoActionPerformed(evt);
            }
        });

        BtnRegistro.setBackground(new java.awt.Color(204, 255, 255));
        BtnRegistro.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnRegistro.setText("Registrar");
        BtnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistroActionPerformed(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Conceptoo.png"))); // NOI18N

        DateFecha.setDateFormatString("dd/MM/YY");

        javax.swing.GroupLayout JpRegistroLayout = new javax.swing.GroupLayout(JpRegistro);
        JpRegistro.setLayout(JpRegistroLayout);
        JpRegistroLayout.setHorizontalGroup(
            JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(JpRegistroLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpRegistroLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(27, 27, 27)
                        .addComponent(TxtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JpRegistroLayout.createSequentialGroup()
                            .addComponent(jLabel11)
                            .addGap(58, 58, 58)
                            .addComponent(DateFecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JpRegistroLayout.createSequentialGroup()
                            .addComponent(jLabel9)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JpRegistroLayout.createSequentialGroup()
                            .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel5)
                                .addComponent(jLabel4))
                            .addGap(45, 45, 45)
                            .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(TxtMonto, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(JpRegistroLayout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboMetododepago, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 212, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(69, 69, 69))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JpRegistroLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(346, 346, 346))
            .addGroup(JpRegistroLayout.createSequentialGroup()
                .addGap(178, 178, 178)
                .addComponent(BtnRegistro)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        JpRegistroLayout.setVerticalGroup(
            JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JpRegistroLayout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(32, 32, 32)
                .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JpRegistroLayout.createSequentialGroup()
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(TxtMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(ComboCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JpRegistroLayout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(31, 31, 31)
                                .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(TxtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10)))
                            .addComponent(DateFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(JpRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(ComboMetododepago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel7))
                .addGap(31, 31, 31)
                .addComponent(BtnRegistro)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        JtableConcepto.addTab("Registro", JpRegistro);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JtableConcepto)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JtableConcepto)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnActualizarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActualizarListaActionPerformed
        // metodo ordenamiento burbuja
        if (camposCompletos()) {
            actualizarRegistro();
        }
            cargarDatosEnTabla();
            actualizarComboMonto(); 
            limpiarCampos();
    }//GEN-LAST:event_BtnActualizarListaActionPerformed

    
    private void BtnRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistroActionPerformed
        if (txtNombre.getText().isEmpty() || TxtMonto.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
        return;
    }

    try {
        double monto = obtenerMonto(); 
        if (monto < 0) {
            JOptionPane.showMessageDialog(this, "El monto no puede ser negativo.");
            return;
        }

        registrarNuevoConcepto(); 
        cargarDatosEnTabla();
        limpiarCampos();
        JtableConcepto.setSelectedComponent(JpLista); 
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Por favor, ingrese un monto válido.");
    }
    }//GEN-LAST:event_BtnRegistroActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        TxtMonto.requestFocus();
    }//GEN-LAST:event_txtNombreActionPerformed

    private void TxtMontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtMontoActionPerformed
        ComboCategoria.requestFocus();
    }//GEN-LAST:event_TxtMontoActionPerformed

    private void ComboCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboCategoriaActionPerformed

    }//GEN-LAST:event_ComboCategoriaActionPerformed

    private void TxtDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtDescripcionActionPerformed
         ComboMetododepago.requestFocus();
    }//GEN-LAST:event_TxtDescripcionActionPerformed

    private void ComboMetododepagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboMetododepagoActionPerformed
       
    }//GEN-LAST:event_ComboMetododepagoActionPerformed

    private void BtnMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnMenuActionPerformed
        FrmMenu menu = new FrmMenu();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BtnMenuActionPerformed

    private void BtnRegistrarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistrarListaActionPerformed
    JtableConcepto.setSelectedComponent(JpRegistro); 
    }//GEN-LAST:event_BtnRegistrarListaActionPerformed

    private void btnBuscarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarListaActionPerformed
        buscar();
        String criterioSeleccionado = (String) ComboBuscar.getSelectedItem();
        String valorSeleccionado = (String) ComboMonto.getSelectedItem();

        if (criterioSeleccionado != null && valorSeleccionado != null) {
            buscarYActualizarTabla(criterioSeleccionado, valorSeleccionado);
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un criterio y un valor.");
        }
    }//GEN-LAST:event_btnBuscarListaActionPerformed

    private void BtnEliminarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarListaActionPerformed
        int filaSeleccionada = JtablaLista.getSelectedRow();
    
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione una fila para eliminar.");
        return;
    }

  
    int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar el registro seleccionado?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
    if (confirmacion == JOptionPane.YES_OPTION) {
        // Eliminar el concepto de la lista de datos
        
        
    
        DefaultTableModel modelo = (DefaultTableModel) JtablaLista.getModel();
        modelo.removeRow(filaSeleccionada);

        JOptionPane.showMessageDialog(this, "Registro eliminado con éxito.");
    }
    }//GEN-LAST:event_BtnEliminarListaActionPerformed

    private void ComboMontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboMontoActionPerformed

    }//GEN-LAST:event_ComboMontoActionPerformed

    private void ComboBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBuscarActionPerformed

    }//GEN-LAST:event_ComboBuscarActionPerformed

    private void BtnOrdernarListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnOrdernarListaActionPerformed
        String criterio = (String) ComboOrden.getSelectedItem();
    if (criterio != null) {
        switch (criterio) {
            case "Nombre":
                break;
            case "Monto":
                break;
            case "Categoria":
                break;
            case "Fecha":
                break;
            case "Descripcion":
                break;
            case "MetodoDePago":
                break;
        }
        
        cargarDatosEnTabla();
    }
    }//GEN-LAST:event_BtnOrdernarListaActionPerformed

    private void ComboOrdenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboOrdenActionPerformed

    }//GEN-LAST:event_ComboOrdenActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmListaConcepto1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmListaConcepto1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmListaConcepto1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmListaConcepto1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmListaConcepto1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnActualizarLista;
    private javax.swing.JButton BtnEliminarLista;
    private javax.swing.JButton BtnMenu;
    private javax.swing.JButton BtnOrdernarLista;
    private javax.swing.JButton BtnRegistrarLista;
    private javax.swing.JButton BtnRegistro;
    private javax.swing.JComboBox<String> ComboBuscar;
    private javax.swing.JComboBox<String> ComboCategoria;
    private javax.swing.JComboBox<String> ComboMetododepago;
    private javax.swing.JComboBox<String> ComboMonto;
    private javax.swing.JComboBox<String> ComboOrden;
    private com.toedter.calendar.JDateChooser DateFecha;
    private javax.swing.JPanel JpLista;
    private javax.swing.JPanel JpRegistro;
    private javax.swing.JTable JtablaLista;
    private javax.swing.JTabbedPane JtableConcepto;
    private javax.swing.JTextField TxtDescripcion;
    private javax.swing.JTextField TxtMonto;
    private javax.swing.JButton btnBuscarLista;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables

    private void actualizarRegistro() {
        String nombre = txtNombre.getText();
        Iterable<Concepto> ListaConcepto = null;
        for (Concepto concepto : ListaConcepto) {
            if (concepto.getNombre().equals(nombre)) {
                try {
                    concepto.setMonto(Double.parseDouble(TxtMonto.getText()));
                    concepto.setCategoria((String) ComboCategoria.getSelectedItem());
                    concepto.setFecha(DateFecha.getDate());
                    concepto.setDescripcion(TxtDescripcion.getText());
                    concepto.setMetodo_pago((String) ComboMetododepago.getSelectedItem());
                    JOptionPane.showMessageDialog(this, "Registro actualizado con éxito.");
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Monto inválido.");
                }
                actualizarComboMonto();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Concepto no encontrado.");
    }

    private void cargarDatosEnTabla() {
        DefaultTableModel modelo = (DefaultTableModel) JtablaLista.getModel();
        modelo.setRowCount(0);
        Iterable<Concepto> listaConceptos = null;

        for (Concepto concepto : listaConceptos) {
            modelo.addRow(new Object[]{
                concepto.getNombre(),
                concepto.getMonto(),
                concepto.getCategoria(),
                concepto.getFecha(),
                concepto.getDescripcion(),
                concepto.getMetodo_pago()
            });
        }
        actualizarComboMonto();
    }

    private void registrarNuevoConcepto() {
        String nombre = txtNombre.getText();
        double monto = obtenerMonto();

        if (monto < 0) {
            JOptionPane.showMessageDialog(this, "El monto no puede ser negativo.");
            return;
        }

        String categoria = (String) ComboCategoria.getSelectedItem();
        Date fecha = DateFecha.getDate();
        String descripcion = TxtDescripcion.getText();
        String metodo_pago = (String) ComboMetododepago.getSelectedItem();

        Concepto nuevoConcepto = new Concepto(nombre, monto, categoria, fecha, descripcion, metodo_pago);
        actualizarComboMonto();
    }
    
    private void limpiarCampos() {
        txtNombre.setText("");
        TxtMonto.setText("");
        ComboCategoria.setSelectedIndex(0);
        DateFecha.setDate(null);
        TxtDescripcion.setText("");
        ComboMetododepago.setSelectedIndex(0);
    }

    private double obtenerMonto() {
        try {
            return Double.parseDouble(TxtMonto.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un valor válido.");
            throw e;
        }
    }
    
    private boolean camposCompletos() {
        if (txtNombre.getText().isEmpty() || TxtMonto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Se acaba de actualizar los Datos a buscar.");
            return false;
        }
        return true;
    }

    private void buscarYActualizarTabla(String criterioSeleccionado, String valorSeleccionado) {
        DefaultTableModel modelo = (DefaultTableModel) JtablaLista.getModel();
        modelo.setRowCount(0);
        Iterable<Concepto> listaConceptos = null;

        for (Concepto concepto : listaConceptos) {
            if (coincideCriterio(concepto, criterioSeleccionado, valorSeleccionado)) {
                modelo.addRow(new Object[]{
                    concepto.getNombre(),
                    concepto.getMonto(),
                    concepto.getCategoria(),
                    concepto.getFecha(),
                    concepto.getDescripcion(),
                    concepto.getMetodo_pago()
                });
            }
        }

        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No se encontraron coincidencias para los criterios seleccionados.");
        }
    }

    private boolean coincideCriterio(Concepto concepto, String criterio, String valor) {
        switch (criterio) {
            case "Nombre":
                return concepto.getNombre().equalsIgnoreCase(valor);
            case "Categoria":
                return concepto.getCategoria().equalsIgnoreCase(valor);
            case "Fecha":
                return concepto.getFecha().toString().contains(valor);
            case "Descripcion":
                return concepto.getDescripcion().contains(valor);
            case "MetodoDePago":
                return concepto.getMetodo_pago().equalsIgnoreCase(valor);
            case "Monto":
                try {
                    return concepto.getMonto() == Double.parseDouble(valor);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Por favor, ingrese un monto válido.");
                    return false;
                }
            default:
                return false;
        }
    }

    private void inicializarCombos() {
    ComboBuscar.addItem("Nombre");
    ComboBuscar.addItem("Categoria");
    ComboBuscar.addItem("Fecha");
    ComboBuscar.addItem("Descripcion");
    ComboBuscar.addItem("MetodoDePago");
    ComboBuscar.addItem("Monto");
    
    ComboOrden.addItem("Nombre");
    ComboOrden.addItem("Monto");
    ComboOrden.addItem("Categoria");
    ComboOrden.addItem("Fecha");
    ComboOrden.addItem("Descripcion");
    ComboOrden.addItem("MetodoDePago");
    actualizarComboMonto();
    }
    
    private void actualizarComboMonto() {
    ComboMonto.removeAllItems(); 

    String criterioSeleccionado = (String) ComboBuscar.getSelectedItem();
    if (criterioSeleccionado == null) {
        ComboMonto.addItem("Seleccione un criterio válido");
        return;
    }

    switch (criterioSeleccionado) {
        case "Nombre":

            break;
        case "Categoria":
            break;
        case "Fecha":

            break;
        case "Descripcion":

            break;
        case "MetodoDePago":

            break;
        case "Monto":
            break;
        default:
            ComboMonto.addItem("Seleccione un criterio");
            break;
    }
}

    private double convertirADouble(String texto) {
        try {
            return Double.parseDouble(texto);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un monto válido.");
            return -1; 
        }
    }

    private void buscar() {
}
}