package EDD;

public class ListaConcepto {
 
}