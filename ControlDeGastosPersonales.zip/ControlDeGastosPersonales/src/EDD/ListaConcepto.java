package EDD;

import Clases.Concepto;
import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableModel;

public class ListaConcepto {
    NodoConcepto cabeza;

    public ListaConcepto() {
        cabeza = null;
    }

    public void agregar(Concepto nuevoConcepto) {
        NodoConcepto nuevoNodo = new NodoConcepto(nuevoConcepto);
        if (cabeza == null) {
            cabeza = nuevoNodo; 
        } else {
            NodoConcepto temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo; 
        }
    }
    
    
    public void listar(DefaultTableModel modelo) {
        modelo.setRowCount(0);
        NodoConcepto temp = cabeza;
        while (temp != null) {
            modelo.addRow(temp.getConcepto().toTableRow());
            temp = temp.siguiente; 
        }
    }
    
    
    public void ordenarPorMonto() {
    if (cabeza == null || cabeza.getSiguiente() == null) {
        return; 
    }

    boolean huboCambio;
    do {
        huboCambio = false;
        NodoConcepto actual = cabeza;

        while (actual.getSiguiente() != null) {
            NodoConcepto siguiente = actual.getSiguiente();

            if (actual.getConcepto().getNombre().compareTo(siguiente.getConcepto().getNombre()) > 0){
                Concepto temp = actual.getConcepto();
                
                actual.setConcepto(siguiente.getConcepto());
                siguiente.setConcepto(temp);
                huboCambio = true; 
            }
            actual = actual.getSiguiente();
        }
    } while (huboCambio);
}


    public Concepto Buscar(String valorBusqueda){
        NodoConcepto actual=cabeza;
        valorBusqueda = valorBusqueda.toLowerCase();
        while (actual !=null){
            Concepto concepto = actual.getConcepto();
            
            if(concepto.getNombre().toLowerCase().contentEquals(valorBusqueda)){
                
                return concepto;
            }
        try {
            double montoBusqueda = Double.parseDouble(valorBusqueda);
            if (concepto.getMonto() == montoBusqueda) {
                return concepto;
            }
        } catch (NumberFormatException e) {
        }
        
        if (concepto.getCategoria().toLowerCase().equals(valorBusqueda)) {
            return concepto;
        }
        
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        String fechaBusqueda = formatoFecha.format(concepto.getFecha());
        if (fechaBusqueda.equals(valorBusqueda)) {
            return concepto;
        }
        
        if (concepto.getDescripcion().toLowerCase().contains(valorBusqueda)) {
            return concepto;
        }
        
        if (concepto.getMetodo_pago().toLowerCase().equals(valorBusqueda)) {
            return concepto;
        }
        
        actual = actual.getSiguiente();
        }
    
        return null;
    }
}