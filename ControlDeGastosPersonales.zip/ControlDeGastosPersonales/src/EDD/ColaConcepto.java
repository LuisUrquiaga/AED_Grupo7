package EDD;

import Clases.Concepto;
import javax.swing.table.DefaultTableModel;

public class ColaConcepto {
    private NodoColaConcepto frente;
    private NodoColaConcepto finalCola;

    public ColaConcepto() {
        frente = finalCola = null;
    }

    public void encolar(Concepto concepto) {
        NodoColaConcepto nuevoNodo = new NodoColaConcepto(concepto);
        if (frente == null) {
            frente = nuevoNodo;
            finalCola = nuevoNodo;
        } else {
            finalCola.setSiguiente(nuevoNodo);
            finalCola = nuevoNodo;
        }
    }

    public Concepto buscar(String valorBusqueda) {
        NodoColaConcepto actual = frente;
        valorBusqueda = valorBusqueda.toLowerCase();

        while (actual != null) {
            Concepto concepto = actual.getConcepto();

            if (concepto.getNombre().toLowerCase().contains(valorBusqueda) ||
                concepto.getCategoria().toLowerCase().contains(valorBusqueda) ||
                String.valueOf(concepto.getMonto()).toLowerCase().contains(valorBusqueda)) {
                return concepto;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    public void listar(DefaultTableModel modelo) {
         NodoColaConcepto actual = getFrente();  

    while (actual != null) {
        Concepto concepto = actual.getConcepto();
        modelo.addRow(new Object[]{
            concepto.getNombre(),
            concepto.getMonto(),
            concepto.getCategoria(),
            concepto.getFecha(),
            concepto.getDescripcion(),
            concepto.getMetodo_pago()
        });
        actual = actual.getSiguiente();
    }
    }

    public void ordenar() {
        if (frente == null || frente.getSiguiente() == null) {
            return;
        }

        boolean intercambiado;
        do {
            intercambiado = false;
            NodoColaConcepto actual = frente;
            NodoColaConcepto anterior = null;

            while (actual != null && actual.getSiguiente() != null) {
                NodoColaConcepto siguiente = actual.getSiguiente();

                String nombreActual = actual.getConcepto().getNombre();
                String nombreSiguiente = siguiente.getConcepto().getNombre();

                if (nombreActual != null && nombreSiguiente != null &&
                    nombreActual.compareTo(nombreSiguiente) > 0) {

                    if (anterior == null) {
                        frente = siguiente;
                    } else {
                        anterior.setSiguiente(siguiente);
                    }
                    actual.setSiguiente(siguiente.getSiguiente());
                    siguiente.setSiguiente(actual);
                    intercambiado = true;
                }
                anterior = actual;
                actual = actual.getSiguiente();
            }
        } while (intercambiado);
    }

    public NodoColaConcepto getFrente() {
        return frente;
    }

    public void setFrente(NodoColaConcepto frente) {
        this.frente = frente;
    }

}