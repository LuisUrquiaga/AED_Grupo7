package EDD;

public class ColaConcepto {
    
}