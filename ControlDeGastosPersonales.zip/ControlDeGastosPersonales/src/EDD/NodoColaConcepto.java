package EDD;

import Clases.Concepto;

public class NodoColaConcepto {

    static NodoColaConcepto getFrente() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private Concepto concepto;
    private NodoColaConcepto siguiente;

    public NodoColaConcepto(Concepto concepto) {
        this.concepto = concepto;
        this.siguiente = null;
    }

    public Concepto getConcepto() {
        return concepto;
    }

    public void setConcepto(Concepto concepto) {
        this.concepto = concepto;
    }

    public NodoColaConcepto getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoColaConcepto siguiente) {
        this.siguiente = siguiente;
    }
}