package EDD;

import Clases.Concepto;

public class NodoConcepto {
    Concepto concepto;
    NodoConcepto siguiente;

    public NodoConcepto(Concepto concepto) {
        this.concepto = concepto;
        this.siguiente = null;
    }

    public Concepto getConcepto() {
        return concepto;
    }

    public void setConcepto(Concepto concepto) {
        this.concepto = concepto;
    }

    public NodoConcepto getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoConcepto siguiente) {
        this.siguiente = siguiente;
    }
    

}
