package EDD;

public class NodoConcepto {
    
}
