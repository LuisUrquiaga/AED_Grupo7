
package arboles;

public class Nodo {
    String dato;
    Nodo izquierda;
    Nodo derecha;

    public Nodo(String valor){
        this.dato = valor;
        this.izquierda = null;
        this.derecha = null;
    }
}
