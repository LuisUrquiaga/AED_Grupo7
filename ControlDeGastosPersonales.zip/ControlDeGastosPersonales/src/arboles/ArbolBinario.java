package arboles;

import java.awt.Color;
import java.awt.Graphics;

public class ArbolBinario {
    Nodo raiz;
    
    public ArbolBinario(){
        raiz = null;
    }
    
    public void insertar(String valor){
        raiz = insertarRecursivo(raiz, valor);
    }
    
    private Nodo insertarRecursivo(Nodo raiz, String valor) {
        if (raiz == null) {
            raiz = new Nodo(valor);
            return raiz;
        }

        if (valor.compareTo(raiz.dato) < 0) {
            raiz.izquierda = insertarRecursivo(raiz.izquierda, valor);                
        } else if (valor.compareTo(raiz.dato) > 0) {
            raiz.derecha = insertarRecursivo(raiz.derecha, valor);     
        }
        return raiz;        
    }
    
    public String preOrden(Nodo nodo){
        String cad = "";
        if (nodo == null) {
            return cad;
        }
        cad += nodo.dato + " ";
        cad += preOrden(nodo.izquierda) + " "; 
        cad += preOrden(nodo.derecha) + " ";
        return cad;    
    }
    
    public String inOrden(Nodo nodo){
        String cad = "";
        if (nodo == null) {
            return cad;
        }        
        cad += inOrden(nodo.izquierda) + " ";
        cad += nodo.dato + " ";      
        cad += inOrden(nodo.derecha) + " ";
        return cad;        
    }
    
    public String posOrden(Nodo nodo){
        String cad = "";
        if (nodo == null) {
            return cad;
        }  
        cad += posOrden(nodo.izquierda) + " ";         
        cad += posOrden(nodo.derecha) + " ";
        cad += nodo.dato + " ";     
        return cad;
    }
    
    public void graficarArbol(Graphics g) {
        if (raiz != null) {
            graficarNodo(g, raiz, 200, 230, 100, "neutro");
        }
    }

    private void graficarNodo(Graphics g, Nodo nodo, int x, int y, int separacion, String lado) {
        if (nodo == null) return;


        if (lado.equals("izquierda")) {
            g.setColor(Color.YELLOW);  
        } else if (lado.equals("derecha")) {
            g.setColor(Color.GREEN);
        } else {
            g.setColor(Color.GRAY);  
        }
        
        g.fillOval(x, y, 50, 50);  
        g.setColor(Color.BLACK);  
        g.drawString(nodo.dato, x + 15, y + 30);  

        if (nodo.izquierda != null) {
            g.drawLine(x + 25, y + 50, x - separacion + 25, y + 100); 
            graficarNodo(g, nodo.izquierda, x - separacion, y + 100, separacion / 2, "izquierda");
        }
        if (nodo.derecha != null) {
            g.drawLine(x + 25, y + 50, x + separacion + 25, y + 100); 
            graficarNodo(g, nodo.derecha, x + separacion, y + 100, separacion / 2, "derecha");
        }
    }
}
