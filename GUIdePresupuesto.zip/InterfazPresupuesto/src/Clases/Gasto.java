package Clases;

public class Gasto {
    private String nombre;
    private String categoria;
    private double monto;

    public Gasto(String nombre, String categoria, double monto) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.monto = monto;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getMonto() {
        return monto;
    }
}
