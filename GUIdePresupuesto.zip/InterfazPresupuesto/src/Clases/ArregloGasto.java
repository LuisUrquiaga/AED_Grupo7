package Clases;
public class ArregloGasto {
    private Gasto[] gastos;
    private int indice;

    public ArregloGasto(int tam) {
        indice = 0;
        gastos = new Gasto[tam];
    }

    public int getIndice() {
        return indice;
    }

    public void add(Gasto gasto) {
        if (indice < gastos.length) {
            gastos[indice] = gasto;
            indice++;
        } else {
            System.out.println("No se pueden agregar más gastos, el arreglo está lleno.");
        }
    }

    public Gasto[] getGastos() {
        return gastos;
    }

    public Gasto getGasto(int pos) {
        if (pos >= 0 && pos < indice) {
            return gastos[pos];
        } else {
            return null; // Retorna null si la posición es inválida
        }
    }
}
